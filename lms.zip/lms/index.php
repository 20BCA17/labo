<?php
// include "auth.php";
include "include/header.php";

?>

<div id="page-wrapper">
    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    Dashboard
                </h1>

            </div>
        </div>
        <?php


        $con = mysqli_connect('localhost', 'root', '', 'hospital');


        $sql = ("SELECT * FROM idx_insert");

        if ($result = mysqli_query($con, $sql)) {

            $rowcount = mysqli_num_rows($result);

            //   printf(" %d\n", );
        }

        // Close the connection
        mysqli_close($con);

        ?>

        <div class="row">
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="panel panel-primary text-center no-boder bg-color-green">
                    <div class="panel-left pull-left green">
                        <i class="fa fa-bar-chart-o fa-5x"></i>

                    </div>
                    <div class="panel-right pull-right">
                        <h3><?php echo $rowcount  ?></h3>
                        <strong>Patient </strong>
                    </div>
                </div>
            </div>




            <?php


            $con = mysqli_connect('localhost', 'root', '', 'hospital');


            $sql = ("SELECT * FROM registration");

            if ($result = mysqli_query($con, $sql)) {

                $rowcount = mysqli_num_rows($result);

                //   printf(" %d\n", );
            }

            // Close the connection
            mysqli_close($con);

            ?>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="panel panel-primary text-center no-boder bg-color-brown">
                    <div class="panel-left pull-left brown">
                        <i class="fa fa-users fa-5x"></i>

                    </div>
                    <div class="panel-right pull-right">
                        <h3><?php echo $rowcount  ?></h3>
                        <strong> Doctor's</strong>

                    </div>
                </div>
            </div>

            <?php


            $con = mysqli_connect('localhost', 'root', '', 'hospital');


            $sql = ("SELECT * FROM appoiment_insert");

            if ($result = mysqli_query($con, $sql)) {

                $rowcount = mysqli_num_rows($result);

                //   printf(" %d\n", );
            }

            // Close the connection
            mysqli_close($con);

            ?>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="panel panel-primary text-center no-boder bg-color-blue">
                    <div class="panel-left pull-left blue">
                        <i class="fa fa-calendar fa-5x"></i>

                    </div>
                    <div class="panel-right pull-right">
                        <h3><?php echo $rowcount  ?></h3>
                        <strong> Appointment</strong>

                    </div>
                </div>
            </div>

            <?php


            $con = mysqli_connect('localhost', 'root', '', 'hospital');


            $sql = ("SELECT * FROM lab_detail_insert");

            if ($result = mysqli_query($con, $sql)) {

                $rowcount = mysqli_num_rows($result);

                //   printf(" %d\n", );
            }

            // Close the connection
            mysqli_close($con);

            ?>
            <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="panel panel-primary text-center no-boder bg-color-red">
                    <div class="panel-left pull-left red">
                        <i class="fa fa-flask fa-5x"></i>

                    </div>
                    <div class="panel-right pull-right">
                        <h3><?php echo $rowcount  ?></h3>
                        <strong> Lab Work</strong>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    include "include/footer.php";
    include "include/script.php";
    ?>