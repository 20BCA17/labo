<nav class="navbar-default navbar-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="main-menu">

            <li>
                <a class="active-menu" href="Dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a>
            </li>
       
            <li>
                <a href="patient.php"><i class="fa fa-users"></i>Patient</a>
            </li>
            <li>
                <a href="manage_doctor.php"><i class="fa fa-bar-chart-o"></i> Doctor</a>
            </li>
            
            <li>
                <a href="lab_detail.php"><i class="fa fa-sitemap"></i>Lab<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="Addlab.php">Add Lab</a>
                    </li>
                    <li>
                        <a href="Add_lab_item.php">Lab Item</a>
                    </li>
                    <li>
                        <a href="lab_detail.php">Lab Work</a>
                    </li>
                </ul>
            </li>
          
            <li>
                <a href="Appoiment.php"><i class="fa fa-calendar" aria-hidden="true"></i> Appointment</a>
            </li>
            
           
        </ul>
       

    </div>

</nav>