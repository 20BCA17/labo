<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">


<!-- Mirrored from webthemez.com/demo/matrix-free-bootstrap-admin-template/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 22 Oct 2015 18:50:10 GMT -->
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LMS </title>
    <link rel = "icon" href ="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTr5GVxw0WtMCRoKCyYT4mZgybq4TseYz1-sQ&usqp=CAU"
        type = "image/x-icon">
    <!-- logo  -->
      <!--  -->

    <!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
 
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="assets//css//custom-styles.css" rel="stylesheet" />

    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' /> -->

    <link href="assets/color/color.css" rel="stylesheet" />
    <link href="assets/css/bcPicker.css" rel="stylesheet" />
    <!-- <link href="css/demo.css" rel="stylesheet" /> -->
    <!-- <link href="css/style.css" rel="stylesheet" /> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    
    <!-- table pagination -->
<link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->

  


<!-- button click hode show table date -->
<script>
$(document).ready(function(){
  $("#hide").click(function(){
    $("").toggle();
  });
  
});
</script>
<style>
#login{
font-weight: bold;
float: right;
background-color:#277BC0;

}
</style>
</head>
<body>


    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
              
                <a class="navbar-brand" href="#">Laboratory Management</a>
            </div>
            <a class="navbar-brand" href="admin/login.php"  id="login">Login</a>
            <ul class="nav navbar-top-links navbar-right nav ">
                <li class="dropdown  dropbtn" >
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <!-- <?php echo $_SESSION['email'] ?>&nbsp;  -->
                        
                        <!-- <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i> -->
                    </a>
                    <div class="dropdown-content">
                 
                    </div>
               </li>
           </ul>
        </nav>
     
                          
  
        <style>


.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 40px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

</style>  