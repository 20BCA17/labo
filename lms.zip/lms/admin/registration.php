<?php include "db.php"; ?>

<?php
session_start();
if (isset($_SESSION['email'])) {
    header("Location: patient.php");
}
?>
<style>
    .custom-file-upload {
        background: #f7f7f7;
        padding: 8px;
        border: 1px solid #e3e3e3;
        border-radius: 5px;
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
    }

    .dark {
        background-color: gray;
        color: white;

    }

    input.parsley-success,
    select.parsley-success,
    textarea.parsley-success {
        color: #468847;
        background-color: #DFF0D8;
        border: 1px solid #D6E9C6;
    }

    input.parsley-error,
    select.parsley-error,
    textarea.parsley-error {
        color: #B94A48;
        background-color: #F2DEDE;
        border: 1px solid #EED3D7;
    }

    .parsley-errors-list {
        margin: 2px 0 3px;
        padding: 0;
        list-style-type: none;
        font-size: 0.9em;
        line-height: 0.9em;
        opacity: 0;

        transition: all .3s ease-in;
        -o-transition: all .3s ease-in;
        -moz-transition: all .3s ease-in;
        -webkit-transition: all .3s ease-in;
    }

    .parsley-errors-list.filled {
        opacity: 1;
    }

    .parsley-type,
    .parsley-required,
    .parsley-equalto {
        color: #ff0000;
    }
</style>

<!DOCTYPE html>
<html>

<head>
    <title>Registration Page</title>
    <link rel="stylesheet" type="text/css" href="css//bootstrap.css">
</head>

<body><br><br>
    <div class="container">
        <div class="row col-md-6 col-md-offset-3">
            <div class="panel panel-primary">
                <div class="panel-heading text-center">
                    <h1>Registration Form</h1>
                </div>
                <div class="panel-body">
                    <form action="registration_insert.php" method="post" id="reg">

                        <div class="form-group">
                            <label for="firstName">FirstName</label>
                            <input type="text" class="form-control" id="firstName" name="firstName" required />
                        </div>
                        <div class="form-group">
                            <label for="lastName">LastName</label>
                            <input type="text" class="form-control" id="lastName" name="lastName" required />
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender</label>
                            <div>
                                <select name="gender" id="" class="form-control">
                                    <option value="M" id="male">Male</option>
                                    <option value="F" id="female">Female</option>
                                    <option value="O" id="others">Others</option>
                                </select>
                                
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" id="email" name="email" required data-parsley-type="email" />
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" placeholder="Password" required data-parsley-length="[8, 16]" data-parsley-trigger="keyup" class="form-control" />
                        </div>
                        <div class="form-group">
                            <label for="cpassword">Confirm Password</label>
                            <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" data-parsley-equalto="#password" data-parsley-trigger="keyup" required class="form-control" />
                        </div>

                        <div class="form-group">
                            <label for="number">Phone Number</label>
                            <input type="text" class="form-control" name="number" data-minlength="10" maxlength="10" id="mobile" data-parsley-minlength="10" data-parsley-minlength-message="minlength 10 number" data-parsley-type="digits" data-parsley-type-message="only numbers" class="input_text" value="" required />
                        </div>
                        <input type="submit" class="btn btn-primary" name="reg" />
                        <a href="login.php">sign in</a>
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>

</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script>
    $("#reg").parsley();
</script>