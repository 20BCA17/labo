<?php
include "auth.php";
include "include/header.php";

?>
<?php
$con = mysqli_connect('localhost', 'root', '', 'hospital'); 

if (isset($_POST['submit'])) {

    $sele_patient = $_POST['sele_patient'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $start_datetime = $_POST['start_datetime'];
    $end_datetime = $_POST['end_datetime'];
    $Chairs = $_POST['Chairs'];
    $Treatmetn = $_POST['Treatmetn'];
    $Notes = $_POST['Notes'];


    $sql = "INSERT INTO appoiment_insert(sele_patient,title,description,start_datetime,end_datetime,Chairs,Treatmetn,Notes)
	 VALUES ('$sele_patient','$title','$description','$start_datetime','$end_datetime','$Chairs','$Treatmetn','$Notes')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !')
        window.location.href = 'Dashboard.php';
      </script>"; 
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>

<div id="page-wrapper">
  <div id="page-inner">

    <div class="row">
      <div class="col-md-12">
        <h1 class="page-header">
          Dashboard
        </h1>

      </div>
    </div>
    <?php


    $con = mysqli_connect('localhost', 'root', '', 'hospital');


    $sql = ("SELECT * FROM idx_insert");

    if ($result = mysqli_query($con, $sql)) {

      $rowcount = mysqli_num_rows($result);

      //   printf(" %d\n", );
    }

    // Close the connection
    mysqli_close($con);

    ?>

    <div class="row">
      <div class="col-md-3 col-sm-12 col-xs-12">
        <div class="panel panel-primary text-center no-boder bg-color-green">
          <div class="panel-left pull-left green">
            <i class="fa fa-bar-chart-o fa-5x"></i>

          </div>
          <div class="panel-right pull-right">
            <h3><?php echo $rowcount  ?></h3>
            <strong><a href="patient.php">Patient</a> </strong>
          </div>
        </div>
      </div>
    

     

      <?php


      $con = mysqli_connect('localhost', 'root', '', 'hospital');


      $sql = ("SELECT * FROM registration");

      if ($result = mysqli_query($con, $sql)) {

        $rowcount = mysqli_num_rows($result);

        //   printf(" %d\n", );
      }

      // Close the connection
      mysqli_close($con);

      ?>
      <div class="col-md-3 col-sm-12 col-xs-12">
        <div class="panel panel-primary text-center no-boder bg-color-brown">
          <div class="panel-left pull-left brown">
            <i class="fa fa-users fa-5x"></i>

          </div>
          <div class="panel-right pull-right">
            <h3><?php echo $rowcount  ?></h3>
            <strong> <a href="manage_doctor.php">Doctor's</a> </strong>

          </div>
        </div>
      </div>

      <?php


      $con = mysqli_connect('localhost', 'root', '', 'hospital');


      $sql = ("SELECT * FROM appoiment_insert");

      if ($result = mysqli_query($con, $sql)) {

        $rowcount = mysqli_num_rows($result);

        //   printf(" %d\n", );
      }

      // Close the connection
      mysqli_close($con);

      ?>
      <div class="col-md-3 col-sm-12 col-xs-12">
        <div class="panel panel-primary text-center no-boder bg-color-blue">
          <div class="panel-left pull-left blue">
            <i class="fa fa-calendar fa-5x"  ></i>

          </div>
          <div class="panel-right pull-right">
            <h3><?php echo $rowcount  ?></h3>
            <strong> <a href="Appoiment.php">Appointment</a></strong>

          </div>
        </div>
      </div>

      <?php


      $con = mysqli_connect('localhost', 'root', '', 'hospital');


      $sql = ("SELECT * FROM lab_detail_insert");

      if ($result = mysqli_query($con, $sql)) {

        $rowcount = mysqli_num_rows($result);

        //   printf(" %d\n", );
      }

      // Close the connection
      mysqli_close($con);

      ?>
      <div class="col-md-3 col-sm-12 col-xs-12">
        <div class="panel panel-primary text-center no-boder bg-color-red">
          <div class="panel-left pull-left red">
            <i class="fa fa-flask fa-5x"></i>

          </div>
          <div class="panel-right pull-right">
            <h3><?php echo $rowcount  ?></h3>
            <strong> <a href="lab_detail.php">Lab Work</a></strong>

          </div>
        </div>
      </div>
      <br><br><br><br><br>
      <br><br><br><br><br><br><br><br><br>
      <?php require_once('db.php') ?>
      <!DOCTYPE html>
      <html lang="en">


      <head>

        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

        <link rel="stylesheet" href="./fullcalendar/lib/main.min.css">
        <script src="./js/jquery-3.6.0.min.js"></script>
        <!-- <script src="./js/bootstrap.min.js"></script>  -->
        <!-- <link rel="stylesheet" href="./css/bootstrap.min.css"> -->
        <script src="./fullcalendar/lib/main.min.js"></script>

      </head>
      <style>
        :root {
          --bs-success-rgb: 71, 222, 152 !important;
        }

        html,
        body {
          height: 100%;
          width: 100%;


        }

        .btn-info.text-light:hover,
        .btn-info.text-light:focus {
          background: #000;
        }

        table,
        tbody,
        td,
        tfoot,
        th,
        thead,
        tr {
          border-color: #ededed !important;
          border-style: solid;
          border-width: 1px !important;

        }

        #calendar {
          width: 130%;
          font-weight: bold;

        }
      </style>
      </head>
      <form action="">
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="color: white;float: right;">
    Add New Appointment
</button>
      </form>
     
      <body class="bg-light">
        <form action="" method="GET">
          <br><br><br><br>
        
          <div class="container py-5" id="page-container">
            <div class="row">
              <div class="col-md-9">
                <div id="calendar"></div>
             
              </div>
            </div>
          </div>
        </form>
          <!-- Event Details Modal -->
          <div class="modal fade" tabindex="-1" data-bs-backdrop="static" id="event-details-modal">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content rounded-0">
                <div class="modal-header rounded-0">
                  <h5 class="modal-title">Schedule Details</h5>
                  <button type="button" data-dismiss="modal" aria-label="Close" style=" position: relative;top: -25px; right: -540px;  ">
                    <i class="fa fa-times" aria-hidden="true"></i>
                  </button>
                </div>
                <?php
                $data = mysqli_query($con, "SELECT * FROM  appoiment_insert ");
                ?>
                <div class="modal-body rounded-0">
                  <div class="container-fluid">
                    <dl>
                      <dt class="text-muted">Patient Name</dt>
                      <dd id="title" class="fw-bold fs-4"></dd> <br>
                      <dt class="text-muted">Doctor_Name</dt>
                      <dd id="description" class="fw-bold fs-4"></dd><br>
                      <dt class="text-muted">Appointment Date</dt>
                      <dd id="start" class="fw-bold fs-4"></dd>


                    </dl>
                  </div>




                </div>
                <div class="modal-footer rounded-0">
                  <div class="text-end">
                    <button type="button" class="btn btn-primary btn-sm rounded-0" id="edit" data-id="">Close</button>
                    <!-- <button type="button" class="btn btn-danger btn-sm rounded-0" id="delete" data-id="">Delete</button> -->
                    <!-- <button type="button" class="btn btn-secondary btn-sm rounded-0" data-bs-dismiss="modal">Close</button> -->
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header" style="background-color: blue; color:white; height: 70px; ">
                  <h4 class="modal-title" id="exampleModalLabel">Appointment</h4>
                  <button type="button" data-dismiss="modal" aria-label="Close" style=" position: relative;top: -25px; right: -540px; background-color:blue; border:1px solid blue;">
                    <i class="fa fa-times" aria-hidden="true" style="color:white;"></i>
                  </button>
                </div>


                <html>

                <head>
                  <link rel="stylesheet" href="app.css">
                </head>

                <body>

                  <div class="modal-body">
                    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                      <div class="cen">
                        <div>
                          <input type="radio" value="Patient" name="sele_patient"><strong>Patient</strong>
                          <input type="radio" value="New Patient" name="sele_patient"><strong>New Patient</strong>

                        </div><br>
                        <div class="">
                          <label for="Patient">Patient</label>
                          <?php

                          require "db.php";
                          $data = mysqli_query($con, "SELECT * FROM idx_insert");

                          echo "<select name=title value='' class='form-control for'>Student Name</option>";

                          foreach ($data as $value) {

                            echo "<option value='$value[Mr] $value[fname] $value[lname]'>$value[Mr] $value[fname] $value[lname]</option>";
                          }

                          echo "</select>";

                          ?>
                        </div><br>
                        <!-- <div class="">
                                     <label for="Doctor Name">Doctor Name</label>
                                     <select name="Doctor_Name" id="" class="form-control for">
                                       <option value="Dr Sahid">Dr Sahid</option>
                                       <option value="Select Patient">Select Patient</option>
                                     </select>
                                   </div> -->
                        <div class="">
                          <label for="Doctor Name">Doctor Name</label>
                          <?php

                          require "db.php";
                          $data = mysqli_query($con, "SELECT * FROM add_doctor");

                          echo "<select name=description value='' class='form-control for'>Student Name</option>";

                          foreach ($data as $value) {

                            echo "<option value='$value[Name]'>$value[Name]</option>";
                          }

                          echo "</select>";

                          ?>
                        </div><br>
                        <div>
                          <div class=" col-md-7 ">

                            <label for="Date & Time "> Date & Time</label>
                            <input type="text" name="start_datetime" value=" <?php
                                                                              $currentDateTime = date('d  F Y h:i A');
                                                                              echo $currentDateTime;
                                                                              ?>" onfocus="this.type='datetime-local'" class="form-control date">

                          </div>
                          <div class=" ">
                            <label for="Date & Time "> <br></label>
                            <select name="end_datetime" id="" class="form-control time">
                              <option value="15 Mins">15 Mins</option>
                              <option value="25 Mins">25 Mins</option>
                              <option value="35 Mins">35 Mins</option>
                            </select>


                          </div><br>
                        </div>
                        <style>
                          .date {
                            width: 250px;
                            margin-left: -14px;
                            /* transform: translate(8%, 50%); */
                          }

                          .cen {
                            justify-content: center;
                            margin-left: 55px;
                          }

                          .area {
                            width: 420px;
                          }
                        </style>
                        <div class="">
                          <label for="Chairs">Chairs</label>
                          <select name="Chairs" id="" class="form-control for">
                            <option value="Select Chair">Select Chair</option>
                            <option value="Select Patient">Select Patient</option>
                          </select>
                        </div><br>
                        <div class="">
                          <label for="Treatmetn">Treatmetn</label>
                          <select name="Treatmetn" id="" class="form-control for">
                            <option value="Select Treatmetn">Select Treatmetn</option>
                            <option value="Select Patient">Select Patient</option>
                          </select>
                        </div><br>
                        <div class="">
                          <label for="Note">Note</label>

                          <textarea name="Notes" id="" cols="80" rows="3" placeholder="Notes" class="form-control area"> </textarea>

                        </div><br>

                        <div class="">
                          Notification On <input type="color">

                          <input type="checkbox" name="" id="Doctor_Appoi"> Doctor
                          <input type="checkbox" name="patient_Appoi">patient

                        </div>
                      </div>
                      <div class="modal-footer ">

                        <input type="submit" name="submit" value="submit" class="btn btn-primary" id="submit">
                        <!-- <button type="button" class="btn btn-defult" style="color:blue;" name="ni"><strong>Save</strong>   </button> -->
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" style="color:black;">Close</button>



                      </div>
                    </form>
                    <!-- Event Details Modal -->

                    <?php
                    $schedules = $con->query("SELECT * FROM `appoiment_insert`");
                    $sched_res = [];
                    foreach ($schedules->fetch_all(MYSQLI_ASSOC) as $row) {
                      // $row[''];
                      $row['sdate'] = date("F d, Y h:i A", strtotime($row['start_datetime']));

                      $sched_res[$row['id']] = $row;
                      // $sched_res[$row['Patient']] = $row;
                    }
                    ?>

                    <?php
                    if (isset($conn)) $conn->close();
                    ?>
                </body>
                <script>
                  var scheds = $.parseJSON('<?= json_encode($sched_res) ?>')
                </script>
                <script src="./js/script.js"></script>

                </html>
                <?php
                include "include/footer.php";
                include "include/script.php";
                ?>