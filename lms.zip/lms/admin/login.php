
<?php include "db.php";

include "include/validation.php";?>

<?php session_start();
if (isset($_SESSION['email'])) {
    header("Location: Dashboard.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Registration Page</title>
    <link rel="stylesheet" type="text/css" href="css//bootstrap.css">
    <!-- CSS only -->

</head>

<body><br> <br> <br>
    <div class="container">
        <div class="row col-md-6 col-md-offset-3">
            <div class="panel panel-primary">
                <div class="panel-heading text-center">
                    <h1>Login Page</h1>
                </div>
                <div class="panel-body">
                    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" id="login">

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" id="email" name="email" placeholder="Email Address/Mobile Number" required data-parsley-type="email">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password"  placeholder="Password" required/>
                        </div>
                       <div class="form-group ">
                              &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="" style="float: right;"> Forgot Password ?</a>
                       </div >
                       <div class="form-group " >
                        <button class="btn btn-primary" type="submit" name="submit"> Login Now</button>
                        

                       </div>

                        Don't have an account ?<a href="registration.php">Sign Up</a>
                    </form>

                    <?php
                if (isset($_POST["submit"])) {
                    include 'db.php';
                    $email = mysqli_real_escape_string($con, $_POST['email']);
                    $password = mysqli_real_escape_string($con, $_POST['password']);
                    $password = md5($password);

                    $sql = "SELECT * FROM registration WHERE email = '{$email}' AND password = '{$password}'"; 
                    // echo $sql; die;
                    $result = mysqli_query($con, $sql) or die("query failed");
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                        // session_start();
                        $_SESSION["email"] = $row['email'];
                        $_SESSION["password"] = $row['password'];
                    
                        header("Location: Dashboard.php");
                        // echo '<div class="alert alert-success>Welcome to dashboard</div>';
                        }
                } else {
                    
               
                    echo "<script>alert('Email or Password Not Matched ')
                    window.location.href = 'login.php';
                  </script>";
                }
            }
?>
                </div>

            </div>
        </div>
    </div>
    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">


    </div>
</body>

</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script>
$("#login").parsley();
</script>