<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
var $button = $('.increment-btn');
var $counter = $('.counter');

$button.click(function(){
  $counter.val( parseInt($counter.val()) + 1 ); 
});
</script>
</head>
<body>
  <form action=""> -->

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> -->
<!-- <input type="text" value="1" class="counter"/>
<button type="button" class="increment-btn">Increment</button>
  </form>
</body>
</html> -->
<!-- <!doctype html>
<?php 
        $slno4=0;		
			
	/*code for auto sl. no. */
	function autoslno()
	{    
          $con=mysqli_connect("localhost","root","",
"hospital"); 

	   $res=mysqli_query($con, "SELECT * FROM idx_insert ");
	   while($row=mysqli_fetch_array($res))
	   {      
	      $id=$row['id'];
	   }
	   $id=$id+1;
           // $slno4= "BRQ/2019/". $slno4;  //Customized form of serial no.
	}
			
	autoslno();     //calling of autosno() function at page load event/where you need.

?>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">   				
   <title>Untitled Document</title>
</head>
<body>  	
        <form class="form-group" name="form1" id="form2" action="" method="post">				
	  <div class="form-group" style="margin-top:25px">
	   <center>
	      <h2>User Registration Page</h2>				
	      <table>
		<tr>
		   <td>SlNo.</td>
		   <td>: </td>
		   <td><input type="text" name="slno1" id="slno2" readonly value="<?php echo $slno4;?>">
                   </td>
		</tr>	
						
		<tr>
		   <td><label for="Nm1">User Name</label></td>
		   <td>:</td>
		   <td><input type="text" class="form-control" name="uname1" id="uname2" autofocus>
		   </td>
		</tr>						
	      </table>
	      <button type="submit" name="Submit1">Submit</button>
	      <button type="submit" name="Delete">Delete</button>
	    </center>
	  </div>	
        </form>	
     </body>
   </html>

   //-------------------------  OR  ------------------------------
<!doctype html>
<?php 
        $id=0;
        $val=0;		
			
	/*code for auto sl. no. */

	    
          $con=mysqli_connect("localhost","root","",
"hospital"); 

$res=mysqli_query($con, "SELECT * FROM idx_insert ");
	   while($row=mysqli_fetch_array($res))
	   {      
	      $id=$row['id'];
              if($id>$val)
                {
                  $val=$id;
                }
	   }
	   $id=$val+1;
           // $slno4= "BRQ/2019/". $slno4;  //Customized form of serial no.
	
			
	autoslno();     //calling of autosno() function at page load event/where you need.

?>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">   				
   <title>Untitled Document</title>
</head>
<body>  	
        <form class="form-group" name="form1" id="form2" action="" method="post">				
	  <div class="form-group" style="margin-top:25px">
	   <center>
	      <h2>User Registration Page</h2>				
	      <table>
		<tr>
		   <td>SlNo.</td>
		   <td>: </td>
		   <td><input type="text" name="slno1" id="slno2" readonly value="<?php echo $id;?>">
                   </td>
		</tr>	
						
		<tr>
		   <td><label for="Nm1">User Name</label></td>
		   <td>:</td>
		   <td><input type="text" class="form-control" name="uname1" id="uname2" autofocus>
		   </td>
		</tr>						
	      </table>
	      <button type="submit" name="Submit1">Submit</button>
	      <button type="submit" name="Delete">Delete</button>
	    </center>
	  </div>	
        </form>	
     </body>
   </html> -->

   <script type="text/javascript">
    function EnableDisableTextBox(btnPassport) {
        var txtPassportNumber = document.getElementById("txtPassportNumber");
        if (btnPassport.value == "Yes") {
            txtPassportNumber.removeAttribute("disabled");
        } else {
            txtPassportNumber.setAttribute("disabled", "disabled");
        }
    }
</script>
<span>Do you have Passport?</span>
<input type="button" value="Yes" onclick="EnableDisableTextBox(this)" />
<input type="button" value="No"  onclick="EnableDisableTextBox(this)"/>
<span ></span>

<hr />
<div>
    Passport Number:
    <input type="text" id="txtPassportNumber" disabled = "disabled"  value="25" />
</div>
