
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Registration</title>
</head>
<body>
<?php
    require('db.php');
    // When form submitted, insert values into the database.
  
        // removes backslashes
        $firstName = stripslashes($_REQUEST['firstName']);
        //escapes special characters in a string
        $firstName = mysqli_real_escape_string($con, $firstName);

        $lastName    = stripslashes($_REQUEST['lastName']);
        $lastName    = mysqli_real_escape_string($con, $lastName);

        $gender = stripslashes($_REQUEST['gender']);
        $gender = mysqli_real_escape_string($con, $gender);

        $email = stripslashes($_REQUEST['email']);
        $email = mysqli_real_escape_string($con, $email);

        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($con, $password);

        $number = stripslashes($_REQUEST['number']);
        $number = mysqli_real_escape_string($con, $number);

        // if(empty($_REQUEST($firstName))){
        //     echo "<span>FirstName Is Required</span>";
        // }

        $query    = "INSERT into `registration` (firstName,lastName, password, email,gender, number)
        VALUES ('$firstName','$lastName', '" . md5($password) . "', '$email','$gender', '$number')";
                     
        $result   = mysqli_query($con, $query);
        if ($result) {
            
            header("Location:index.html");
        } else {
            echo "failed";
        }


   
    
?>
   
</body>
</html>