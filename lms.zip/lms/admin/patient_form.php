<?php
$Patient_Code = 0;
$val = 0;

/*code for auto sl. no. */


$con = mysqli_connect(
    "localhost",
    "root",
    "",
    "hospital"
);

$res = mysqli_query($con, "SELECT * FROM idx_insert ");
while ($row = mysqli_fetch_array($res)) {
    $Patient_Code = $row['Patient_Code'];
    if ($Patient_Code > $val) {
        $val = $Patient_Code;
    }
}
$Patient_Code = $val + 1;
// $slno4= "BRQ/2019/". $slno4;  //Customized form of serial no.


//calling of autosno() function at page load event/where you need.

?>
<?php
include "auth.php";
include "include/header.php";
include "include/validation.php";
?>



<html>

<head>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>   -->

    <script>
        <?php
        $date = date("Y-m-d");
        ?>

        function ageCalculator() {
            var userinput = document.getElementById("DOB").value;
            var dob = new Date(userinput);
            if (userinput == null || userinput == '') {
                document.getElementById("message").innerHTML = "**Choose a date please!";
                return false;
            } else {

                //calculate month difference from current date in time  
                var month_diff = Date.now() - dob.getTime();

                //convert the calculated difference in date format  
                var age_dt = new Date(month_diff);

                //extract year from date      
                var year = age_dt.getUTCFullYear();

                //now calculate the age of the user  
                var age = Math.abs(year - 1970);
                document.getElementById("mytxt").value = age;
                //display the calculated age  
                return document.getElementById("result").innerHTML =
                    age;
            }
        }

        function EnableDisableTextBox(btnPassport) {
        var txtPassportNumber = document.getElementById("txtPassportNumber");
        if (btnPassport.value == "Yes") {
            txtPassportNumber.removeAttribute("readonly");
        } else {
            txtPassportNumber.setAttribute("readonly", "readonly");
        }
    }
    </script>


</head>

<body>
    <div id="page-wrapper">
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Dashboard <small>Summary of your App</small>
                    </h1>

                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Laboratory Management
                        </div>
                        <div class="panel-body">
                            <div class="form-row">
                                <div class="col-lg-12">
                                    <form id="patientData" method="POST" role="form" action="patient_insert.php" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h1 class="page-header ">
                                                    Personal Details
                                            </div>
                                        </div>

                                     
                                     <div class="col-md-3">
                                        <input type="text" onfocus="(this.type='date')" class="form-control" name="Today_Date" value="<?php
                                                                                                                                    $currentDateTime = date('d-F-Y');
                                                                                                                                    echo $currentDateTime;
                                                                                                                                    ?>">
                                    </div>


                                        <div class="form-group col-md-3">

                                            <?php

                                            require "db.php";
                                            $data = mysqli_query($con, "SELECT * FROM add_doctor");

                                            echo "<select name=Doctor_Name value='' class='form-control'>Student Name</option>";

                                            foreach ($data as $value) {

                                                echo "<option value=$value[Name]>$value[Name]</option>";
                                            }

                                            echo "</select>";

                                            ?>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group input-group ">

                                                <input type="text" class="form-control" placeholder="OPD No :" name="Patient_Code" value="<?php echo $Patient_Code; ?>"   id="txtPassportNumber" readonly onmouseout="EnableDisableTextBox(this)">

                                                <span class="input-group-btn">
                                                    <button class="btn btn-primary" type="button"  value="Yes"  onclick="EnableDisableTextBox(this)"><i class="fa fa-pen" ></i>

                                                    </button>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="ph">

                                            <script type="text/javascript">
                                                function preview(event) {
                                                    var reader = new FileReader();
                                                    reader.onload = function() {
                                                        var output = document.getElementById('output_image');
                                                        output.src = reader.result;
                                                    }
                                                    reader.readAsDataURL(event.target.files[0]);
                                                }
                                            </script>
                                            <img id="output_image" height="155px" width="125px" />
                                            <input name="UploadDocument" type="file" id="choose" accept=".jpg,.jpeg,.pdf,doc,docx,application/msword,.png" style="display: none;" onchange="preview(event)" accept="image/*" /><br><br>

                                            <center>
                                                <label for="choose" class="custom-file-upload" id="choose-label">Select Photo</label>
                                            </center>
                                        </div>

                                        <div class="form-group col-md-2">
                                            <select name="Mr" id="" class="form-control">
                                                <option value="Mr">Mr</option>
                                                <option value="Mrs">Mrs</option>
                                                <option value="Ms">Ms</option>
                                                <option value="Miss">Miss</option>
                                            </select>
                                        </div>



                                        <div class="form-group col-md-3">
                                            <input type="text" name="fname" id="first_name" placeholder="First Name" class="form-control" required data-parsley-pattern="^[a-zA-Z]+$" data-parsley-trigger>
                                        </div>
                                        <div class="form-group col-md-3">
                                            <input type="text" name="lname" id="" placeholder="Last Name" class="form-control" name="Name" required data-parsley-pattern="^[a-zA-Z]+$">
                                        </div>

                                        <div class="form-group col-md-3">
                                            <input type="text" placeholder="Date Of Birth" onfocus="(this.type='date')" class="form-control" name="dob" max="<?php echo "$date" ?>" required id=DOB onmouseout="ageCalculator()">
                                        </div>


                                        <div class="form-group col-md-1 ">
                                            <input type="text" name="dob_year" value="0" class="form-control" id="mytxt" readonly>
                                            <!-- <button type="submit"  id="result" class="btn " disabled style="border: 1px solid gray;" name="dob_year"> age</button> -->
                                        </div>
                                        <div class="form-group col-md-1 ">
                                            <input type="text" name="dob_month" id="" value="<?php echo date('M'); ?>" class="form-control" readonly>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <select name="gender" id="" class="form-control" name="Gender" required>
                                                <option>Gender</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                                <option value="Other">Other</option>

                                            </select>
                                        </div><br><br><br><br><br><br><br><br><br>

                                        <div class="form-group col-md-4">
                                            <input type="text" placeholder="mobile" class="form-control" name="Phone" data-minlength="10" maxlength="10" id="mobile" data-parsley-minlength="10" data-parsley-minlength-message="minlength 10 number" data-parsley-type="digits" data-parsley-type-message="only numbers" class="input_text" value="" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <input type="email" placeholder="Email" class="form-control" name="mail" required data-parsley-type="email">
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h1 class="page-header ">
                                                    Contact Details
                                            </div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <input type="text" placeholder="Flat/Door/Block No" class="form-control" name="flat" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <input type="text" placeholder="Road/ Street/Lane" class="form-control" name="road" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <input type="text" placeholder="Place" class="form-control" name="place" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <select name="country" id="" class="form-control" readonly>

                                                <option value="">India</option>
                                                <option value="">Us</option>
                                                <option value="">Pk</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <select name="state" id="" class="form-control" readonly>

                                                <option value="">Gujarat</option>
                                                <option value="">Maharastra</option>
                                                <option value="">Uttar Pradesh</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <input type="text" name="pin" id="" placeholder="Pin/Zip Code" class="form-control" required>
                                        </div> <br><br><br><br><br><br>
                                        <div>
                                            <input type="submit" name="submit" value="submit" class="btn btn-primary" id="submit">



                                            <input type="submit" name="save_sub" value="Save & Add More Patient" class="btn btn-primary">
                                            <button class="btn btn-primary" type="reset">Reset</button>
                                        </div>

                                    </form>
                                </div>
                            </div>



</body>

</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script>
    $("#patientData").parsley();
</script>
<?php
include "include/footer.php";
include "include/script.php";
?>