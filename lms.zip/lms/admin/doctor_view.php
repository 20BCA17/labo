
<?php
include_once 'db.php';
$result = mysqli_query($con, "SELECT * FROM add_doctor WHERE id='" . $_GET['id'] . "'");
$row = mysqli_fetch_array($result);

?>
<?php
include "auth.php";
include "include/header.php";
?>
<style>
    .thumb {
        height: 80px;
        border: 1px solid #000;
        margin: 10px 5px 0 0;
        width: 300px;
    }

    .photo {
        height: 155px;
        border: 1px solid #000;
        margin: 10px 5px 0 0;
        width: 125px;
    }

    .color-picker {
        width: 30px;
        height: 30px;
        padding: 5px;
        float: right;
        top: -4px;
    }

    .display-inline {
        display: inline-block;
    }

    .middle-hex {

        font-size: 13px;
        color: #bdbdbd;
        vertical-align: top;

        text-transform: uppercase;
    }

    .middle-hex span {
        color: #292929;
        margin-left: 10px;
    }

    .bcPicker-palette {
        top: 36px !important;

    }

    .custom-file-upload {
        background: #f7f7f7;
        padding: 8px;
        border: 1px solid #e3e3e3;
        border-radius: 5px;
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
    }

    #dynamicCheck {
        float: right;
        cursor: pointer;
        position: relative;
        margin-top: -45px;
        top: -10px;


        bottom: -150px;
    }



    .custom-file-upload {
        background: #f7f7f7;
        padding: 8px;
        border: 1px solid #e3e3e3;
        border-radius: 5px;
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
    }

    .dark {
        background-color: gray;
        color: white;

    }

    input.parsley-success,
    select.parsley-success,
    textarea.parsley-success {
        color: #468847;
        background-color: #DFF0D8;
        border: 1px solid #D6E9C6;
    }

    input.parsley-error,
    select.parsley-error,
    textarea.parsley-error {
        color: #B94A48;
        background-color: #F2DEDE;
        border: 1px solid #EED3D7;
    }

    .parsley-errors-list {
        margin: 2px 0 3px;
        padding: 0;
        list-style-type: none;
        font-size: 0.9em;
        line-height: 0.9em;
        opacity: 0;

        transition: all .3s ease-in;
        -o-transition: all .3s ease-in;
        -moz-transition: all .3s ease-in;
        -webkit-transition: all .3s ease-in;
    }

    .parsley-errors-list.filled {
        opacity: 1;
    }

    .parsley-type,
    .parsley-required,
    .parsley-equalto {
        color: #ff0000;
    }

    .sty {
        width: 80%;
    }
</style>


<html>

<head>
    <script>
        function myFunction() {
            var name = document.getElementById("name").value;
            document.getElementById("namespan").textContent = name;
        }
    </script>
</head>

<body>



    <div id="page-wrapper">
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Dashboard <small>Summary of your App</small>
                    </h1>
                   
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                        Basic Details
                    </h1>
                </div>
            </div>
            <!-- form input doctor details-->
            <div class="form-row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Laboratory Management
                        </div>

                        <div class="panel-body">
                            <div class="form-row">
                                <div class="col-lg-12">

                                    <form action="adddoc_insert.php"  id="patientData" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <div class="col-md-4 form-group">

                                            <input type="text" class="form-control" placeholder="Mobile Number" data-minlength="10" maxlength="10" id="mobile" data-parsley-minlength="10" data-parsley-minlength-message="minlength 10 number" data-parsley-type="digits" data-parsley-type-message="only numbers" class="input_text" value="<?php echo $row['Phone_No']; ?>" required/  name="Phone_No" readonly>
                                        </div>
                                        <div class="col-md-4 form-group">

                                            <input type="text" class="form-control" placeholder="Name"   name="Name" required value="<?php echo $row['Name']; ?>" readonly>
                                        </div>
                                        <div class="col-md-4 form-group">

                                            <input type="email" class="form-control" placeholder="Email Id"  data-parsley-type="email" name="email" required value="<?php echo $row['email']; ?>" readonly>
                                        </div>
                                        <div class="col-md-6 form-group">

                                            <input type="text" class="form-control" placeholder="Registration number/Id"  name="reg_id" required value="<?php echo $row['reg_id']; ?>" readonly>
                                        </div>
                                        <div class="col-md-3 form-group">
                                            <div class="color-container">
                                                <!-- <div id="bcPicker1" class="color-picker display-inline"></div> -->
                                                <div class="form-control">
                                                    <div class="middle-hex display-inline "> </div>
                                                    <div id="bcPicker1" class="color-picker display-inline form-control" name="color"></div>
                                                    <div class="middle-hex display-inline" ><span ></span> </div>
                                                  
                                                </div>

                                            </div>

                                        </div>
                                        <!-- <input type="text" name="" id="" class="color-picker display-inline form-control"> -->
                                </div>
                                <!-- <div class="middle-hex  display-inline"><span>RGB(0, 0, 0)</span></div> -->
                                <!-- </div> -->
                            </div>
                           

                            <hr><br><br><br><br><br><br>
                            <div>
                                <div class="col-md-6 form-group">
                                
                                 <img id="output_image" height=155px width=125px src="upload/<?php echo $row['UploadDocument']; ?>"><br><br>
                                 

                                </div>
                            </div>
                       
                            <div class="col-md-6 form-group">

                              
                                </script>
                                <img id="output_imag" height=80px width=300px src="upload/sing/<?php echo $row['sign']; ?>"><br><br>
                               
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <h2 class="page-header ">
                                        Appointment Timeing
                                    </h2>
                                </div>
                            </div>

                            <table class="table form-group col-md-1 ">
                                <tr>
                                    <th> Start Time </th>
                                    <th> End Time </th>
                                    <th> Slot No </th>
                                </tr>
                                <td class="col-md-2">


                                    <input type="text" placeholder="10:00" onfocus="(this.type='time')" class="form-control sty" name="start_time" value="<?php echo $row['start_time']; ?>" readonly>
                                </td>

                                <td class="col-md-2">

                                    <input type="text" placeholder="10:00" onfocus="(this.type='time')" class="form-control sty" name="End_time" value="<?php echo $row['End_time']; ?>" readonly>


                                </td>

                                <td class="col-md-3">

                                    <input type='Number' class="form-control sty" placeholder='1' name="Slot_No" value="<?php echo $row['Slot_No']; ?>" readonly>
                                </td>

                            </table>

                            <div id="newElementId"></div>

                            <script type="text/JavaScript">
                                function createNewElement() {
                                                      // First create a DIV element.
                                                    var txtNewInputBox = document.createElement('div');


                                                      // Then add the content (a new input box) of the element.
                                                    txtNewInputBox.innerHTML = "<table  class='table form-group col-md-1' ><td class='col-md-2'><input type='text' id='newInputBox' class='form-control sty' placeholder='10:00' onfocus=(this.type='time') name='start_time'></td><td class='col-md-2'> <input type='text' id='newInputBox' class='form-control sty' onfocus=(this.type='time') placeholder='10:00' name='End_time'> </td><td class='col-md-3'><input type='Number' id='newInputBox' class='form-control sty' placeholder='1' name='Slot_No'></td></table>";

                                                      // Finally put it where it is supposed to appear.
                                                    document.getElementById("newElementId").appendChild(txtNewInputBox);

                                                  }
                                                  </script>

                            <div id="dynamicCheck">
                                <button onclick="createNewElement();" type="button" class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i></button><br><br><br>

                            </div>
                            <div>
                                    
                                        <a href="manage_doctor.php" <button class="btn btn-primary">Back</button></a>
                                    </div>
                            </form>
                        </div>
                    </div>

                </div>
</body>

</html>

<?php
include "include/footer.php";
include "include/script.php";
?>