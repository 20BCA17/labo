

<?php

include "include/validation.php";
?>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="css//bootstrap.css">


	<!-- FontAwesome Styles-->
	<link href="assets/css/font-awesome.css" rel="stylesheet" />

	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

	<style>
		.cng {

			transform: translate(8%, 50%);
		}
	</style>
</head>

<body><br> <br> <br>


	<div class="container">
		<div class="row col-md-6 col-md-offset-3">
			<div class="panel panel-primary">
				<div class="panel-heading text-center">
					<h1>Change Password</h1>
				</div>
				<div class="panel-body">

					<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" class="text-center" id="cng">
						<div class="cng">

							<div class="form-group col-lg-10 " align="left">
								<label for="Old Password:">Old Password:</label>
								<input type="password" name="password" placeholder="Current password" class="form-control"  >
							</div>

							<div class="form-group col-lg-10" align="left">
								<label for="new Password:">new Password:</label>
								<input type="password" name="newpassword" placeholder="New password"  class="form-control" required data-parsley-length="[8, 16]" data-parsley-trigger="keyup">
							</div>
							<div class="form-group col-lg-10" align="left"> 
								<label for="confirm Password:">confirm Password:</label>
								<input type="password" name="confpassword" placeholder=" confirm password"  class="form-control" data-parsley-equalto="#password" data-parsley-trigger="keyup" required>
							</div>

							<div class="form-group col-md-3">
								<!-- <button  class="btn btn-danger" >Update Password</button> <br> -->
								<button class="btn btn-info" name="submit" type="submit"><i class=" fa fa-refresh "></i> Update Password </button>
								
							</div>

						</div>

				</div>
			</div>
		</div>
		<div class="toast" role="alert" aria-live="assertive" aria-atomic="true">


		</div>



		<?php
    // include 'auth.php';
		include 'db.php';
		if (isset($_POST["submit"])) {	
			session_start();
			$c = mysqli_real_escape_string($con, $_POST['password']);
			$newpassword = mysqli_real_escape_string($con, $_POST['newpassword']);
			// $oldpass = md5($c);
			// echo ($oldpass); die;

			if ($_SESSION['password'] == md5($c)) {
				
				$sql1 = "UPDATE registration SET password='" . md5($newpassword)  . "' WHERE email='" . $_SESSION["email"] . "'";
				// echo $sql1; die;
				mysqli_query($con, $sql1);
				mysqli_close($con);
				
				echo "<script>alert('Password Has been Updated ')
								window.location.href = 'login.php';
							  </script>";
			} else {
				echo "<script>alert('Input Correct Password');</script>";
			}
		}

		?>



		</form> <br>&nbsp;&nbsp;&nbsp;

		<br>


	</div>

	</div>
	<?php
	include "include/footer.php";
	include "include/script.php";
	?>

	</div>

</body>

</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script>
$("#cng").parsley();
</script>