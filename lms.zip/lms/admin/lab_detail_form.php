<?php
include "auth.php";
include "include//header.php";
?>

<style>
    .thumb {
        height: 155px;
        border: 1px solid #000;
        margin: 10px 5px 0 0;
        width: 125px;

    }

    .nu {
        text-align: center;
        text-decoration: none;
        
    }

    .doc {
        color: green;
    }

    a:hover {
        text-decoration: none;

    }

    .n {
        border: 1px solid black;
        width: 100px;
        height: 110px;
        text-align: center;
    }

    .in {
        display: inline-block;
    }

    #dynamicCheck {
        float: right;
        cursor: pointer;
        position: relative;
        margin-top: -45px;
        top: -10px;


        bottom: -150px;
    }

    .sty {
        width: 80%;

    }
</style>

<div id="page-wrapper">
    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    Dashboard <small>Summary of your App</small>
                </h1>
                
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Basic Form Elements
                    </div>
                    <div class="panel-body">
                        <div class="form-row">
                            <div class="col-lg-12">
                                <form action="lab_detail_insert.php" role="form" method="POST" id="lab_detail" >

                                <div class="form-group col-md-4" >
                                    
                                  
                                    <?php

require "db.php";
$data = mysqli_query($con, "SELECT * FROM idx_insert");

echo "<select name=Patient_Name value='' class='form-control for'>Student Name</option>";

foreach ($data as $value) {

    echo "<option value='$value[fname]'>$value[fname]</option>";
}

echo "</select>";

?>
                                </div>

                                    <div class="form-group col-md-4">
                                        <input type="text" onfocus="(this.type='date' )" class="form-control" name="Start_Date" value="<?php
                                                                                                                                        $currentDateTime = date('d-F-Y');
                                                                                                                                        echo $currentDateTime;
                                                                                                                                        ?>">
                                    </div>
                                    <div class="form-group col-md-4">
                                        
                                        <?php

require "db.php";
$data = mysqli_query($con, "SELECT * FROM add_lab_insert");

echo "<select name=Select_Lab value='' class='form-control for'>Student Name</option>";

foreach ($data as $value) {

    echo "<option value='$value[Lab_Name]'>$value[Lab_Name]</option>";
}

echo "</select>";

?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        
                                        <?php

require "db.php";
$data = mysqli_query($con, "SELECT * FROM add_doctor");

echo "<select name=Doctor_Name value='' class='form-control for'>Student Name</option>";

foreach ($data as $value) {

    echo "<option value='$value[Name]'>$value[Name]</option>";
}

echo "</select>";

?>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" onfocus="(this.type='date')" class="form-control" name="End_Date" value="<?php
                                                                                                                                    $currentDateTime = date('d-F-Y');
                                                                                                                                    echo $currentDateTime;
                                                                                                                                    ?>">
                                    </div> <br> <br> <br> <br><br> <br>
                                    <div class="form-group col-md-12">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="exampleRadios" value="New Case">
                                            New Case
                                            &nbsp; &nbsp; &nbsp;
                                            <input class="form-check-input" type="radio" name="exampleRadios" value="Continuation Of Case">
                                            Continuation Of Case
                                            &nbsp; &nbsp; &nbsp;
                                            <input class="form-check-input" type="radio" name="exampleRadios" value="Repeat">
                                            Repeat
                                        </div>
                                    </div>
                                    <div class="form-group col-md-2">
                                        <select name="Theeth_No" id="" class="form-control">
                                            <option value="A1">A1</option>
                                            <option value="A2">A2</option>
                                            <option value=""></option>

                                        </select>
                                    </div>

                                    <div class="form-group col-md-3">
                                        <select name="Sent" id="" class="form-control">
                                            <option value="Sent">Sent</option>
                                            <option value=""></option>
                                            <option value=""></option>

                                        </select>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <select name="Select_Stage" id="" class="form-control">
                                            <option value="Select Stage">Select Stage</option>
                                            <option value=""></option>
                                            <option value=""></option>

                                        </select>
                                    </div> <br><br>
                                    <div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="Primary Teeth" name="Toothinfo">
                                            Primary Teeth
                                            &nbsp; &nbsp; &nbsp;
                                            <input class="form-check-input" type="checkbox" value="Select All Teeth" name="Toothinfo">
                                            Select All Teeth
                                        </div>
                                    </div>

                                    <br>

                                    <div class="table-responsive" >
                                                <table class="table table-bordered border-primary responsive" >

                                            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

                                            <script>
                                                $(document).ready(function() {
                                                    $('.nu').on('click', function() {
                                                        $(this).css("background-color", "gray");
                                                        $('#demo').append($(this).children().text());
                                                        $('#demo').append($('<input type="checkbox" value="test">' + '<br>'));

                                                    });
                                                });
                                            </script>


                                            <tr>

                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//11.png" alt=""></div>
                                                    <div class="doc" id="first">11</div>
                                                </td>


                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//12.png" alt=""></div>
                                                    <div class="doc">12</div>
                                                </td>

                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//13.png" alt=""></div>
                                                    <div class="doc">13</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//14.png" alt=""></div>
                                                    <div class="doc">14</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//15.png" alt=""></div>
                                                    <div class="doc">15</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//16.png" alt=""></div>
                                                    <div class="doc">16</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//17.png" alt=""></div>
                                                    <div class="doc">17</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//18.png" alt=""></div>
                                                    <div class="doc" id="dot_01" onclick="dot_01(this)">18</div>
                                                </td>
                                                <td class="nu">
                                                    <div class="doc" id="dot_01" onclick="dot_01(this)"><img src="img//21.png" alt=""></div>
                                                    <div>21</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//22.png" alt=""></div>
                                                    <div class="doc">22</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//23.png" alt=""></div>
                                                    <div class="doc">23</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//24.png" alt=""></div>
                                                    <div class="doc">24</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//25.png" alt=""></div>
                                                    <div class="doc">25</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//26.png" alt=""></div>
                                                    <div class="doc">26</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//27.png" alt=""></div>
                                                    <div class="doc">27</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//28.png" alt=""></div>
                                                    <div class="doc">28</div>
                                                </td>
                                            </tr>
                                            <tr>

                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//31.png" alt=""></div>
                                                    <div class="doc">31</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//32.png" alt=""></div>
                                                    <div class="doc">32</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//33.png" alt=""></div>
                                                    <div class="doc">33</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//34.png" alt=""></div>
                                                    <div class="doc">34</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//35.png" alt=""></div>
                                                    <div class="doc">35</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//36.png" alt=""></div>
                                                    <div class="doc">36</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//37.png" alt=""></div>
                                                    <div class="doc">37</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//38.png" alt=""></div>
                                                    <div class="doc">38</div>
                                                </td>
                                                <td class="nu">

                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//41.png" alt=""></div>
                                                    <div class="doc">41</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//42.png" alt=""></div>
                                                    <div class="doc">42</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//43.png" alt=""></div>
                                                    <div class="doc">43</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//44.png" alt=""></div>
                                                    <div class="doc">44</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//45.png" alt=""></div>
                                                    <div class="doc">45</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//46.png" alt=""></div>
                                                    <div class="doc">46</div>
                                                </td>

                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//47.png" alt=""></div>
                                                    <div class="doc">47</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//48.png" alt=""></div>
                                                    <div class="doc">48</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="nu">

                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//1A.png" alt=""></div>
                                                    <div class="doc">1A</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//1B.png" alt=""></div>
                                                    <div class="doc">1B</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//1C.png" alt=""></div>
                                                    <div class="doc">1C</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//1D.png" alt=""></div>
                                                    <div class="doc">1D</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//1E.png" alt=""></div>
                                                    <div class="doc">1E</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//2A.png" alt=""></div>
                                                    <div class="doc">2A</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//2B.png" alt=""></div>
                                                    <div class="doc">2B</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//2C.png" alt=""></div>
                                                    <div class="doc">2C</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//2D.png" alt=""></div>
                                                    <div class="doc">2D</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//2E.png" alt=""></div>
                                                    <div class="doc">2E</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//3A.png" alt=""></div>
                                                    <div class="doc">3A</div>
                                                </td>
                                                <td class="nu">


                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//3B.png" alt=""></div>
                                                    <div class="doc">3B</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//3C.png" alt=""></div>
                                                    <div class="doc">3C</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//3D.png" alt=""></div>
                                                    <div class="doc">3D</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//3E.png" alt=""></div>
                                                    <div class="doc">3E</div>
                                                </td>
                                                <td class="nu">
                                                    <div id="dot_01" onclick="dot_01(this)"><img src="img//4A.png" alt=""></div>
                                                    <div class="doc">4A</div>
                                                </td>
                                            </tr>

                                            <td class="nu">

                                                <div id="dot_01" onclick="dot_01(this)"><img src="img//4B.png" alt=""></div>
                                                <div class="doc">4B</div>
                                            </td>
                                            <td class="nu">
                                                <div id="dot_01" onclick="dot_01(this)"><img src="img//4C.png" alt=""></div>
                                                <div class="doc">4C</div>
                                            </td>
                                            <td class="nu">
                                                <div id="dot_01" onclick="dot_01(this)"><img src="img//4D.png" alt=""></div>
                                                <div class="doc">4D</div>
                                            </td>
                                            <td class="nu">
                                                <div id="dot_01" onclick="dot_01(this)"><img src="img//4E.png" alt=""></div>
                                                <div class="doc">4E</div>
                                            </td>


                                        </table>
                                    </div>
                                  
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="page-header ">
                                                Components
                                            </h3>
                                        </div>
                                    </div>
                                   
 
                                    <table class="table form-group col-md-1 ">
                                        <td class="col-md-4">


                                            <?php

require "db.php";
$data = mysqli_query($con, "SELECT * FROM add_item_insert");

echo "<select name=	Select_Components_items value='' class='form-control for'>Select Components items</option>";

foreach ($data as $value) {

    echo "<option value='$value[Component_Name]'>$value[Component_Name]</option>";
}

echo "</select>";

?>

                                        </td>

                                        <td >

											<div class="btn-group" style="width:80%;">
											  <button data-toggle="dropdown" class=" dropdown-toggle form-control" >Select Tooth  <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<span id="demo"></span>
											  </ul>
											</div>
                                        </td>

                                        <td class="col-md-4 ">

                                            <input type='Number' class='form-control sty' placeholder='₹' name="Price">


                                        </td>
                                    </table>

                                    <div id="newElementId"></div>
                                    <script type="text/JavaScript">
                                        function createNewElement() {
                                                  // First create a DIV element.
                                                var txtNewInputBox = document.createElement('div');
                                              
                                                  // Then add the content (a new input box) of the element.
                                                txtNewInputBox.innerHTML = "<table  class='table form-group col-md-1' ><td class='col-md-4'><select class='form-control sty' name='Select_Components_items'><option>Select Components items</option><option></option></td><td class='col-md-3'><select class='form-control sty' name='Select_Tooth'><option>Select Tooth </option><option></option> </td><td class='col-md-4'><input type='Number'  class='form-control sty' placeholder='₹' name='Price'></td></table>";
                                              
                                                  // Finally put it where it is supposed to appear.
                                                document.getElementById("newElementId").appendChild(txtNewInputBox);
                                              }
                                              </script>
                                    <div id="dynamicCheck" class="ri">
                                        <button onclick="createNewElement();" type="button" class="btn btn-info"><i class="fa fa-plus" aria-hidden="true"></i></button><br><br><br>

                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="page-header ">
                                                Pontic Design

                                            </h3>

                                        </div>
                                    </div>
                                    
                                                <table class="table table-bordered border-primary" >
                                                <div class="table-responsive" >

                                            <tr>
                                                <div>
                                                    <td class="nu">

                                                        <div><img src="img//modified-ridge.png" alt=""></div><br><br>
                                                        <div class="doc">modified-ridge</div>
                                                    </td>
                                                    <td class="nu">
                                                        <div><img src="img//hygienic.png" alt=""></div><br><br>
                                                        <div class="doc">hygienic</div>
                                                    </td>
                                                    <td class="nu">
                                                        <div><img src="img//full-ridge.png" alt=""></div><br><br>
                                                        <div class="doc">full-ridge</div>
                                                    </td>
                                                    <td class="nu">
                                                        <div><img src="img//ovate.png" alt=""></div><br><br>
                                                        <div class="doc">ovate</div>
                                                    </td>
                                                </div>
                                            </tr>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h3 class="page-header ">
                                                    Collar and Metal Design

                                                </h3>

                                            </div>
                                        </div>
                                        <div>
                                            <tr>
                                                <table class="table table-bordered border-primary">
                                                    <td class="nu">
                                                        <div><img src="img//no-collar.png" alt=""></div><br><br>
                                                        <div class="doc">no-collar</div>
                                                    </td>
                                                    <td class="nu">
                                                        <div><img src="img//lingual-collar.png" alt=""></div><br><br>
                                                        <div class="doc">lingual-collar</div>
                                                    </td>
                                                    <td class="nu">
                                                        <div><img src="img//360-collar.png" alt=""></div><br><br>
                                                        <div class="doc">360-collar</div>
                                                    </td>
                                                    <td class="nu">
                                                        <div><img src="img//facing.png" alt=""></div><br><br>
                                                        <div class="doc">facing</div>
                                                    </td>
                                        </div>
                                        </tr>
                                        </div>
                                        </table>
                                   
                                    <hr>
                                    <div class="form-group col-lg-5">

                                        <input type="text" class="form-control" placeholder="Total Cost" name="Total_Cost" required />
                                    </div>
                                    <div class="form-group col-md-2">
                                        <select name="Order_Placed" id="" class="form-control">
                                            <option value="Order Placed">Order Placed</option>
                                            <option value=""></option>
                                            <option value=""></option>
                                            <option value=""></option>
                                        </select>

                                    </div>
                                    <div class="form-group">
                                        <textarea rows="4" cols="100" placeholder="Instruction" class="form-control" name="Instruction"></textarea>
                                    </div><br>
                                    <div>
                                        <input type="checkbox" value="1" checked name="lab_status"> is Active
                                    </div><br>
                                    <div>
                                        <input type="submit" name="submit" value="submit" class="btn btn-success">
                                        <button class="btn btn-primary"><a href="lab_detail.php" style="color: white;">Cancle
                                    </div></button>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        </form>
        <!-- /. ROW  -->

    </div>

</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script>
    $("#lab_detail").parsley();
</script>
<?php
include "include/footer.php";
include "include/script.php";
?>