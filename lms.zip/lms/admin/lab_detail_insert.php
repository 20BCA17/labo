<?php
include_once 'db.php';

if (isset($_POST['submit'])) {

    $Patient_Name = $_POST['Patient_Name'];
    $Start_Date = $_POST['Start_Date'];
    $Select_Lab = $_POST['Select_Lab'];
    $Doctor_Name = $_POST['Doctor_Name'];
    $End_Date = $_POST['End_Date'];
    $exampleRadios = $_POST['exampleRadios'];
    $Theeth_No = $_POST['Theeth_No'];
    $Sent = $_POST['Sent'];
    $Select_Stage = $_POST['Select_Stage'];
    $Toothinfo = $_POST['Toothinfo'];

    $Select_Components_items = $_POST['Select_Components_items'];
    $Select_Tooth = $_POST['Select_Tooth'];
    $Price = $_POST['Price'];
    $Total_Cost = $_POST['Total_Cost'];
    $Order_Placed = $_POST['Order_Placed'];
    $Instruction = $_POST['Instruction'];
    $lab_status = $_POST['lab_status'];



    $sql = "INSERT INTO lab_detail_insert(Patient_Name,Start_Date,Select_Lab,Doctor_Name,End_Date,exampleRadios,Theeth_No,Sent,Select_Stage,Toothinfo,Select_Components_items,Select_Tooth,Price,Total_Cost,Order_Placed,Instruction,lab_status)
	 VALUES ('$Patient_Name','$Start_Date','$Select_Lab','$Doctor_Name','$End_Date','$exampleRadios','$Theeth_No','$Sent','$Select_Stage','$Toothinfo','$Select_Components_items','$Select_Tooth','$Price','$Total_Cost','$Order_Placed','$Instruction','$lab_status')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !')
        window.location.href = 'lab_detail.php';
      </script>";
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}


?>
<?php

include_once 'db.php';



if (isset($_POST['update'])) {
    $id = $_POST['id'];

    $Start_Date = $_POST['Start_Date'];
    $Select_Lab = $_POST['Select_Lab'];
    $Doctor_Name = $_POST['Doctor_Name'];
    $End_Date = $_POST['End_Date'];
    $exampleRadios = $_POST['exampleRadios'];
    $Theeth_No = $_POST['Theeth_No'];
    $Sent = $_POST['Sent'];
    $Select_Stage = $_POST['Select_Stage'];
    $Toothinfo = $_POST['Toothinfo'];
    $Select_Components_items = $_POST['Select_Components_items'];

    $Select_Tooth = $_POST['Select_Tooth'];
    $Price = $_POST['Price'];
    $Total_Cost = $_POST['Total_Cost'];
    $Order_Placed = $_POST['Order_Placed'];
    $Instruction = $_POST['Instruction'];
    $Patient_Name = $_POST['Patient_Name'];

     $update = "UPDATE lab_detail_insert set Start_Date='$Start_Date',Select_Lab='$Select_Lab',Doctor_Name='$Doctor_Name',End_Date='$End_Date',exampleRadios='$exampleRadios',Theeth_No='$Theeth_No',Sent='$Sent',Select_Stage='$Select_Stage',Toothinfo='$Toothinfo',Select_Components_items='$Select_Components_items',Select_Tooth='$Select_Tooth',Price='$Price',Total_Cost='$Total_Cost',Order_Placed='$Order_Placed',Instruction='$Instruction',Patient_Name='$Patient_Name'  WHERE id='$id'";
// echo $update;die;
 
    if (mysqli_query($con, $update)) {

        echo "<script>alert('updated successfully !')
        window.location.href = 'lab_detail.php';
      </script>";
    } else {
        echo "Error: " . $update . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}
  

?>
  
<?php
include_once 'db.php';
$delete = "DELETE FROM lab_detail_insert WHERE id='" . $_GET["id"] . "'";
if (mysqli_query($con, $delete)) {
    header("location:lab_detail.php");
} else {
    echo "Error deleting record: " . mysqli_error($con);
}
mysqli_close($con);
?>

<?php

if (isset($_POST['Add'])) {

    header("location:lab_detail_form.php");
}

?>
