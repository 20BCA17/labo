<?php
include "auth.php";
include "include/header.php";
?>
<?php
include_once 'db.php';
$result = mysqli_query($con, "SELECT * FROM Add_lab_insert WHERE id='" . $_GET['id'] . "'");
$row = mysqli_fetch_array($result);

?>
<div id="page-wrapper">
    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    Dashboard <small>Summary of your App</small>
                </h1>
               
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    Basic Details
                </h1>
            </div>
        </div>
        <!-- form input doctor details-->
        <div class="form-row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Laboratory Management
                    </div>

                    <div class="panel-body">
                        <div class="form-row">
                            <div class="col-lg-12">

                                <form action="Add_lab_insert.php" role="form" method="POST" data-parsley-validate="">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <div class="col-md-6 form-group">


                                        <input type="text" class="form-control" placeholder="Lab Name(*)" name="Lab_Name" data-parsley-trigger="change" required value="<?php echo $row['Lab_Name']; ?>">
                                    </div>


                                    <div class="col-md-6 form-group ">

                                        <input type="text" class="form-control" placeholder="Registration(*)" name="Registration" value="<?php echo $row['Registration']; ?>">
                                    </div>

                                    <div class="col-md-6 form-group">

                                        <input type="text" class="form-control" placeholder="Contact person(*)" name="Contact" value="<?php echo $row['Contact']; ?>">
                                    </div>

                                    <div class="col-md-6 form-group">

                                        <input type="text" class="form-control" placeholder="Mobile Number" name="Mobile_No" value="<?php echo $row['Mobile_No']; ?>">
                                    </div>
                                    <div class="col-md-6 form-group">

                                        <input type="email" class="form-control" placeholder="Email Address 1(*)" name="Email_Add1" value="<?php echo $row['Email_Add1']; ?>">
                                    </div>
                                    <div class="col-md-6 form-group">

                                        <input type="email" class="form-control" placeholder="Email Address 2(*)" name="Email_Add2" value="<?php echo $row['Email_Add2']; ?>">
                                    </div>



                                    <div class="row">
                                        <div class="col-md-12">
                                            <h2 class="page-header ">
                                                Address Details
                                            </h2>
                                        </div>
                                    </div>


                                    <div class="form-group col-md-12">
                                        <input type="text" class="form-control" placeholder="Address Line 1(*)" name="Address_Line1" value="<?php echo $row['Address_Line1']; ?>">
                                    </div>


                                    <div class=" form-group col-md-12">

                                        <input type="text" class="form-control" placeholder="Address Line 2(*)" name="Address_Line2" value="<?php echo $row['Address_Line2']; ?>">
                                    </div>


                                    <div class="form-group col-md-6">
                                        <select id="" class="form-control" name="Country" >
                                            <option value="India">India</option>
                                            <option value=""></option>
                                            <option value=""></option>
                                            <option value=""></option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <select id="" class="form-control" name="State">
                                            <option value="Gujarat">Gujarat</option>
                                            <option value=""></option>
                                            <option value=""></option>
                                            <option value=""></option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">

                                        <input type="text" class="form-control" placeholder="City" name="City" value="<?php echo $row['City']; ?>">
                                    </div>
                                    <div class="form-group col-md-6">

                                        <input type="text" class="form-control" placeholder="Pin/Zip Code" name="Pin" value="<?php echo $row['Pin']; ?>">
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h2 class="page-header ">
                                                Notes
                                            </h2>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <textarea name="Notes" id="" cols="100" rows="10" placeholder="Notes" class="form-control" > </textarea>
                                    </div>
                                    <div class="checkbox">
                                        <input type="checkbox" checked name="Active"> Is Active
                                    </div><br>
                                    <div class="btn">
                                        <!-- <input type="submit" name="update" value="Update" class="btn btn-success"> -->
                                        <button class="btn btn-info" name="update" type="submit"><i class=" fa fa-refresh "></i> Update </button>
                                        <button class="btn btn-primary">Cancle</button>
                                    </div>
                                </form>
                            </div>

                        </div>

                        <?php
                        include "include/footer.php";
                        include "include/script.php";
                        ?>