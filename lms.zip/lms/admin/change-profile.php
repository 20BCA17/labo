<?php
session_start();
//  ob_start();

include("db.php");

?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="css//bootstrap.css">



<link href="assets/css/font-awesome.css" rel="stylesheet" />

<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>

    <?php
    if (isset($_SESSION['email'])) {

        if (isset($_POST['submit'])) {
            $firstName = $_POST['firstName'];
            $lastName = $_POST['lastName'];
            $gender = $_POST['gender'];
            $email = $_POST['email'];
           

            $s = mysqli_query($con, "UPDATE registration SET firstName='$firstName', lastName='$lastName',gender='$gender',email='$email' WHERE email='" . mysqli_real_escape_string($con, $_SESSION["email"]) . "'");

            if ($s) {
                echo "<script type='text/javascript'>alert('Successful - Record Updated!'); window.location.href = 'logout.php';</script>";
            } else {
                echo "<script type='text/javascript'>alert('Unsuccessful - ERROR!'); window.location.href = 'change-profile.php';</script>";
            }
        }

        $query1 = mysqli_query($con, "SELECT * FROM registration WHERE email='" . mysqli_real_escape_string($con, $_SESSION["email"]) . "'");
        $query2 = mysqli_fetch_array($query1);
        // $row = mysqli_fetch_array($result);
    ?>

<div class="container">
		<div class="row col-md-6 col-md-offset-3">
			<div class="panel panel-primary">
				<div class="panel-heading text-center">
					<h1>Change Profile</h1>
				</div>
				<div class="panel-body">
        <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" id="reg">

            <div class="form-group">
                <label for="firstName">FirstName</label>
                <input type="text" class="form-control" id="firstName" name="firstName" required value="<?php echo $query2['firstName'];  ?>" />
            </div>
            <div class="form-group">
                <label for="lastName">LastName</label>
                <input type="text" class="form-control" id="lastName" name="lastName" required value="<?php echo $query2['lastName'];  ?>" />
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
                <div>
                <select name="gender" id="" class="form-control" >
                                    <option value="Male" id="male"
                                    <?php
                                    if($query2['gender'] == 'Male'){
                                        echo "selected";
                                    }
                                    ?>
                                    >Male</option>
                                    
                                    <option value="Female" id="female"
                                    
                                    <?php
                                    if($query2['gender'] == 'Female'){
                                        echo "selected";
                                    }
                                    ?>>Female</option>
                                    <option value="Others" id="others"
                                    
                                    <?php
                                    if($query2['gender'] == 'Others'){
                                        echo "selected";
                                    }
                                    ?>>Others</option>
                                </select>
                                
                            </div>
                    <!-- <label for="male" class="radio-inline"><input type="radio" name="gender" value="m" id="male" value="<?php echo $query2['gender'];  ?>" />Male</label>
                    <label for="female" class="radio-inline"><input type="radio" name="gender" value="f" id="female" value="<?php echo $query2['gender'];  ?>" />Female</label>
                    <label for="others" class="radio-inline"><input type="radio" name="gender" value="o" id="others" value="<?php echo $query2['gender'];  ?>" />Others</label> -->
                </div>
           

            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" id="email" name="email" required data-parsley-type="email" value="<?php echo $query2['email'];  ?>" />
            </div>
            <!-- <input type="submit" name="submit" value="Update" /> -->
            <button class="btn btn-info" name="submit" type="submit"><i class=" fa fa-refresh "></i> Update Password </button>
        </form>
        </div>

</div>
</div>
</div>



</div>
    <?php
        //  close  while  loop
    }


    ?>


    </br>

</body>

</html>