<form class="form-horizontal" action="search_keyword.php">
 Analysegegenstand
  <select>
      <label class="col-md-4 control-label" for="searchinput">Analysegegenstand</label>
    <option disabled selected id="searchinput" name="type_select" type="select">Analysegegenstand wählen</option>
    <?php
        include "db_connect.php";
        
        $records = mysqli_query($mysqli, "SELECT Analysegegenstand From Analysegegenstand"); 

        while($data = mysqli_fetch_array($records))
        {
            echo "<option value='". $data['Analysegegenstand'] ."'>" .$data['Analysegegenstand'] ."</option>"; 
        }   
    ?>  
  </select>
  

</fieldset>
</form>