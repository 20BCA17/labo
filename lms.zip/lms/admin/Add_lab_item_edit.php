<?php
include "auth.php";
include "include/header.php";
?>
<?php
include_once 'db.php';
$result = mysqli_query($con, "SELECT * FROM add_item_insert WHERE id='" . $_GET['id'] . "'");
$row = mysqli_fetch_array($result);

?>

<div id="page-wrapper">
    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    Dashboard <small>Summary of your App</small>
                </h1>
                
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Laboratory Management
                    </div>
                    <div class="panel-body">
                        <div class="form-row">
                            <div class="col-lg-12">


                                <form action="Add_lab_item_insert.php" method="POST" role="form" enctype="multipart/form-data" id="patientData">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h2 class="page-header ">
                                                Labitem
                                            </h2>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <select name="Component_Category" class="form-control">
                                            <option value="Select Component Category">Select Component Category</option>
                                            <option value=""></option>
                                            <option value=""></option>
                                            <option value=""></option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">

                                        <input type="text" class="form-control" placeholder="Component Name" name="Component_Name" required value="<?php echo $row['Component_Name']; ?>">
                                    </div>

                                    <div class="form-group  col-md-6">

                                        <input type="text" class="form-control" placeholder=" Component Discription" name="Component_Discription" required value="<?php echo $row['Component_Discription']; ?>">
                                    </div>

                                    <div class="form-group  col-md-6">

                                        <input type="text" class="form-control" placeholder=" ₹ 0" name="Cost" required value="<?php echo $row['Cost']; ?>">
                                    </div>

                                    <div class="btn">
                                        <!-- <input type="submit" name="update" value="update" class="btn btn-success"> -->
                                        <button class="btn btn-info" name="update" type="submit"><i class=" fa fa-refresh "></i> Update </button>
                                        <button class="btn btn-primary"><a href="Add_lab_item.php" style="color: white;">Cancle</a></button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
include "include/footer.php";
include "include/script.php";
?>