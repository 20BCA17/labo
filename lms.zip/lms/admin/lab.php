<?php 
include "auth.php";
include "include/header.php";
?>
<style>
        /* Image Designing Propoerties */
        .thumb {
            height: 80px;
            border: 1px solid #000;
            margin: 10px 5px 0 0;
            width: 300px;
        }
</style>
      
<div id="page-wrapper">
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                            Dashboard <small>Summary of your App</small>
                    </h1>
					<ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Library</a></li>
                        <li class="active">Data</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Basic Details
                        </h1>
                    </div>
                </div>
                <!-- form input doctor details-->
                <div class="form-row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Laboratory Management
                            </div>

                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">

                                        <form action="" role="form" class="">

                                            <div class="col-md-6 form-group">
                                                <input type="text" class="form-control" placeholder="Lab Name(*)">
                                            </div>


                                            <div class="col-md-6 form-group ">
                                                <input type="text" class="form-control" placeholder="Registration(*)">
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <input type="text" class="form-control" placeholder="Content person(*)">
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <input type="text" class="form-control" placeholder="Mobile Number">
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <input type="email" class="form-control"
                                                    placeholder="Email Address 1(*)">
                                            </div>

                                            <div class="col-md-6 form-group">
                                                <input type="email" class="form-control"
                                                    placeholder="Email Address 2(*)">
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h2 class="page-header ">
                                                        Address Details
                                                    </h2>
                                                </div>
                                            </div>

                                            <div class="form-group col-md-12">
                                                <input type="text" class="form-control" placeholder="Address Line 1(*)">
                                            </div>

                                            <div class=" form-group col-md-12">

                                                <input type="text" class="form-control" placeholder="Address Line 2(*)">
                                            </div>


                                            <div class="form-group col-md-6">
                                                <select name="" id="" class="form-control">
                                                    <option value="">India</option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <select name="" id="" class="form-control">
                                                    <option value="">Gujarat</option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">

                                                <input type="text" class="form-control" placeholder="City">
                                            </div>
                                            <div class="form-group col-md-6">

                                                <input type="text" class="form-control" placeholder="Pin/Zip Code">
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h2 class="page-header ">
                                                        Notes
                                                    </h2>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <textarea name="" id="" cols="100" rows="10" placeholder="Notes"
                                                    class="form-control"> </textarea>
                                            </div>
                                            <div class="checkbox">
                                                <input type="checkbox"> Is Active
                                            </div>
                                            <HR>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h2 class="page-header ">
                                                        Labitem
                                                    </h2>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <select name="" id="" class="form-control">
                                                    <option value="">Select Component Category</option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                </select>
                                            </div>

                                            <div class="form-group col-md-6">

                                                <input type="text" class="form-control" placeholder="Component Name">
                                            </div>
                                            <div class="form-group  col-md-6">

                                                <input type="text" class="form-control"
                                                    placeholder=" Component Discription">
                                            </div>

                                            <div class="form-group  col-md-6">

                                                <input type="text" class="form-control" placeholder=" ₹ 0">
                                            </div>
                                          
                                            <div class="btn">
                                                <button class="btn btn-primary">Save</button>
                                                <button class="btn btn-primary">Cancle</button>
                                            </div>


                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
</div>

<?php 
    include "include/footer.php";
    include "include/script.php";
?>