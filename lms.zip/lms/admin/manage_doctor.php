<?php
include "auth.php";
include "include/header.php";
?>

<style>
    .custom-file-upload {
        background: #f7f7f7;
        padding: 8px;
        border: 1px solid #e3e3e3;
        border-radius: 5px;
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
    }

    .dark {
        background-color: gray;
        color: white;

    }

    .icon {
        text-align: center;

    }

    .od {

        border-radius: 50px;
        background-color: #06d69f;
        font-size: 12px;
        color: white;
        text-align: center;
        padding: 10px;

    }

    img {
        background: url(n.png);
        background-repeat: no-repeat;
        background-size: 100px 100px;


    }
</style>

<div id="page-wrapper">
    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    Doctor
                </h1>
               
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Laboratory Management
                    </div>
                    <div class="panel-body">
                        <div class="form-row">
                            <div class="col-lg-12">
                                <form action="" role="form" method="POST" enctype="multipart/form-data">


                                   

                                    <div class="form-group ">

                                        <div>
                                           <button  class="btn btn-primary " style="float: right;color:white;"><a href="adddoctor.php" style="color:white;">Add Doctor New
                                                </a> </button>
                                        </div>
                                        <!-- <button  class="btn btn-primary " id="hide"
                                                    style="float: right;" >Add
                                                    New
                                                    Patient </button> -->
                                    </div><br><br><br>
                                    <!-- table in data store -->
                                    <?php require "db.php"; ?>
                                    <?php
                                    $data = mysqli_query($con, "SELECT * FROM add_doctor");
                                    ?>
                                    <div class="dt">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover  " id="dataTables-example">
                                                <thead>
                                                    <tr class="dark">
                                                        <th>Sr</th>
                                                        <th>Image</th>
                                                        <th>Name</th>
                                                        <th>Patient_Code</th>
                                                        <th>Status</th>
                                                        
                                                        <th class="icon">Action</th>

                                                    </tr>
                                                </thead>
                                                <?php foreach ($data as $value) { ?>
                                                    <tr>
                                                       <td><?php echo $value['id']; ?></td>
                                                        <td><?php echo $value['Name']; ?></td>
                                                        <td><?php echo $value['email']; ?></td>
                                                        <td><?php echo $value['Phone_No']; ?></td>
                                                        <td><?php
                                                         if($value['stauts']==1){
                                                            echo  '<p><a href="active.php?id='.$value['id'] .'&stauts=0" class="btn btn-success">Active</a></p>';
                                                         }
                                                         else{
                                                            echo  '<a href="active.php?id='.$value['id'] .'&stauts=1" class="btn btn-danger">Deactive</a>';

                                                         }
                                                        ?></td>
                                                        <td class="icon">
                                                        <a href="Doctor_edit.php?id=<?php echo $value['id']; ?>">
              <font color='Blue ' size='4px'><i class="fas fa-edit" aria-hidden="true"></i></font>
            </a>
                                                            &nbsp;
                                                            <a onclick="return confirm('Are you sure?')" href="adddoc_insert.php?id=<?php echo $value['id']; ?>" >
                                                                <font color='red ' size='4px'><i class="fa fa-trash "></i><span class="tooltiptext"></span></font>
                                                            </a>
                                                            &nbsp;

                                                            <a href="doctor_view.php?id=<?php echo $value['id']; ?>">
                                                                <font color='black' size='4px'><i class="fa fa-eye" aria-hidden="true"></i></font>
                                                            </a>
                                                        </td>

                                                    </tr>

                                                <?php } ?>
                                            </table>

                                           
                                        </div>
                                    </div>
                                </form>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    include "include/footer.php";
    include "include/script.php";
    ?>