<?php require "db.php";?>
<?php
header('Content-Type:application/xls');
header('Content-Disposition:atttachment;filename=report.xls');
        ?>
                                           <?php
                                                $data = mysqli_query($con, "SELECT * FROM idx_insert");
                                            ?>
                                            <table class="table table-striped table-bordered">
                                                <thead>
                                                    <tr class="dark">
                                                       
                                                        <th>Patient_Code</th>
                                                        <!-- <th>Age</th> -->
                                                        <th>Gender</th>
                                                        <th>Contact</th>
                                                       
                                                        
                                                    </tr>
                                                </thead>
                                               <?php foreach ($data as $value) {?>
                                                <tr>
                                                        
                                                        <td><?php echo $value['dob_year']; ?></td>
                                                        <td><?php echo $value['gender']; ?></td>
                                                        <td><?php echo $value['Phone']; ?></td>
                                                
                                                </tr>
                                                <?php }?>
                                          </table>

      