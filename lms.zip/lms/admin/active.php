<?php
include_once 'db.php';

$id =$_GET['id'];
$stauts = $_GET['stauts'];

$done = "UPDATE add_doctor set stauts='$stauts' WHERE id='$id'";
// echo $update; die;
mysqli_query($con,$done);
header('location:manage_doctor.php');

?>