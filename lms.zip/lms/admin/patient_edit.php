
<?php
include "auth.php";
include "include/header.php";
?>
<?php
include_once 'db.php';
$result = mysqli_query($con, "SELECT * FROM idx_insert WHERE id='" . $_GET['id'] . "'");
$row = mysqli_fetch_array($result);

?>
<style>
    .custom-file-upload {
        background: #f7f7f7;
        padding: 8px;
        border: 1px solid #e3e3e3;
        border-radius: 5px;
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
    }

    .dark {
        background-color: gray;
        color: white;

    }
</style>

<head>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>   -->

    <script>
        <?php
        $date = date("Y-m-d");
        ?>

function ageCalculator() {  
    var userinput = document.getElementById("DOB").value;  
    var dob = new Date(userinput);  
    if(userinput==null || userinput=='') {  
      document.getElementById("message").innerHTML = "**Choose a date please!";    
      return false;   
    } else {  
      
    //calculate month difference from current date in time  
    var month_diff = Date.now() - dob.getTime();  
      
    //convert the calculated difference in date format  
    var age_dt = new Date(month_diff); 
    var month_diff = date('month_diff');  
      
    //extract year from date      
    var year = age_dt.getUTCFullYear();  
      
    //now calculate the age of the user  
    var age = Math.abs(year - 1970);  
      document.getElementById("mytxt").value= age;
    //display the calculated age  
    return document.getElementById("result").innerHTML =    
              age ;  
    }  
}  
function EnableDisableTextBox(btnPassport) {
        var txtPassportNumber = document.getElementById("txtPassportNumber");
        if (btnPassport.value == "Yes") {
            txtPassportNumber.removeAttribute("readonly");
        } else {
            txtPassportNumber.setAttribute("readonly", "readonly");
        }
    }
    </script>


</head>

<div id="page-wrapper">
    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    Dashboard <small>Summary of your App</small>
                </h1>
               
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Laboratory Management
                    </div>
                    <div class="panel-body">
                        <div class="form-row">
                            <div class="col-lg-12">

                                <form action="patient_insert.php" role="form" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">


                            </div>

                            <div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <h1 class="page-header ">
                                            Personal Details
                                    </div>
                                </div>

                                
                                <div class="col-lg-3">
                                        <input type="text" onfocus="(this.type='date' )" class="form-control" name="Today_Date" value=" <?php echo $row['Today_Date']; ?> ">
                                    </div>
                                <div class="form-group col-md-3">
                                    <select name="Doctor_Name" id="" class="form-control">
                                        <option value="Dr Nitin">Dr Nitin</option>
                                        <option value=""></option>
                                        <option value=""></option>
                                        <option value=""></option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group input-group ">
                                        <input type="text" class="form-control" placeholder="OPD No :" name="Patient_Code" value=" <?php echo $row['Patient_Code']; ?>" id="txtPassportNumber" readonly onmouseout="EnableDisableTextBox(this)">
                                        <span class="input-group-btn">
                                        <button class="btn btn-primary" type="button"  value="Yes"  onclick="EnableDisableTextBox(this)"><i class="fa fa-pen" ></i>
                                        </span>
                                    </div>
                                </div>
                                
                                <div>
                                    <div class="ph">

                                        <script type="text/javascript">
                                            function preview(event) {
                                                var reader = new FileReader();
                                                reader.onload = function() {
                                                    var output = document.getElementById('output_image');
                                                    output.src = reader.result;
                                                }
                                                reader.readAsDataURL(event.target.files[0]);
                                            }
                                        </script>

                                        <img id="output_image" height=155px width=125px src="upload/<?php echo $row['UploadDocument']; ?>">
                                        <input name="UploadDocument" type="file" id="choose" accept=".jpg,.jpeg,.pdf,doc,docx,application/msword,.png" style="display: none;" onchange="preview(event)" accept="image/*" /><br><br>

                                        <center>
                                            <label for="choose" class="custom-file-upload" id="choose-label">Select Photo</label>
                                        </center>
                                    </div>



                                    <div class="form-group col-md-2">
                                        <select name="Mr" id="" class="form-control">
                                            <option value="Mr">Mr</option>
                                            <option value="Mrs">Mrs</option>
                                            <option value="Ms">Ms</option>
                                            <option value="Miss">Miss</option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-3">
                                        <input type="text" name="fname" id="" placeholder="First Name" class="form-control" value="<?php echo $row['fname']; ?>">
                                    </div>
                                    <div class="form-group col-md-3">
                                        <input type="text" name="lname" id="" placeholder="Last Name" class="form-control" value="<?php echo $row['lname']; ?>">
                                    </div>

                                    <div class="form-group col-md-3">
                                        <input type="text" placeholder="Date Of Birth" onfocus="(this.type='date')" class="form-control" name="dob" value="<?php echo $row['dob']; ?>" id = DOB onmouseout = "ageCalculator()" >
                                    </div>

                                    <div class="form-group col-md-1 ">
                                    
                                        <input type="text" name="dob_year"  value="<?php echo $row['dob_year']; ?>" class="form-control"   id="mytxt" readonly>
                                    </div>
                                    <div class="form-group col-md-1 ">
                                        <input type="button" name="dob_month" id="month_diff" value="<?php echo  date('M', strtotime($row['dob'])); ?>" class="form-control" readonly>
                                    </div>
                                    <div class="form-group col-md-2">
                                        <select name="gender" id="" class="form-control" name="Gender">
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Other">Other</option>

                                        </select>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <input type="text" placeholder="mobile" class="form-control" name="Phone" data-minlength="10" maxlength="10" id="mobile" value="<?php echo $row['Phone']; ?>">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="email" placeholder="Email" class="form-control" name="mail" value="<?php echo $row['mail']; ?>">
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h1 class="page-header ">
                                                Contact Details
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" placeholder="Flat/Door/Block No" class="form-control" name="flat" value="<?php echo $row['flat']; ?>">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" placeholder="Road/ Street/Lane" class="form-control" name="road" value="<?php echo $row['road']; ?>">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" placeholder="Place" class="form-control" name="place" value="<?php echo $row['place']; ?>">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <select name="country" id="" class="form-control" readonly>

                                            <option value="">India</option>
                                            <option value="">Us</option>
                                            <option value="">Pk</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <select name="state" id="" class="form-control" readonly>

                                            <option value="">Gujarat</option>
                                            <option value="">Maharastra</option>
                                            <option value="">Uttar Pradesh</option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <input type="text" name="pin" id="" placeholder="Pin/Zip Code" class="form-control" value="<?php echo $row['pin']; ?>">
                                    </div>


                                    <br><br><br><br><br><br>
                                    <div>
                                    <!-- <input type="submit" name="update" value="Update" class="btn btn-success"> -->
                                    <button class="btn btn-info" name="update" type="submit"><i class=" fa fa-refresh "></i> Update </button>
                                        <a href="patient.php" <button class="btn btn-primary">Cancle</button></a>
                                    </div>

                                </div>

                            </div>
                        </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "include/footer.php";
include "include/script.php";
?>