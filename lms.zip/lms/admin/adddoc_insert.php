<?php
include_once 'db.php';

if (isset($_POST['submit'])) {
    $Phone_No = $_POST['Phone_No'];
    $Name = $_POST['Name'];
  
    $email = $_POST['email'];
    // $UploadDocument = $_POST['UploadDocument'];
    $reg_id = $_POST['reg_id'];
    $color = $_POST['color'];
    $start_time = ($_POST['start_time']);

    // echo "<pre>"; print_r($start_time); die;
    $End_time = $_POST['End_time'];
    $Slot_No = $_POST['Slot_No'];
   


    $name = $_FILES['UploadDocument']['name'];
    list($txt, $ext) = explode(".", $name);
    $image_name = time() . "." . $ext;
    $tmp = $_FILES['UploadDocument']['tmp_name'];

    move_uploaded_file($tmp, 'upload/' . $image_name);


    $name = $_FILES['sign']['name'];
    list($txt, $ext) = explode(".", $name);
    $img_name = time() . "." . $ext;
    $tmp_n = $_FILES['sign']['tmp_name'];

    move_uploaded_file($tmp_n, 'upload/sing/' . $img_name);
   

    $sql = "INSERT INTO add_doctor (Phone_No,Name,email,reg_id,color,UploadDocument,sign,start_time,End_time,Slot_No)
	 VALUES ('$Phone_No','$Name','$email','$reg_id','$color','$image_name','$img_name','$start_time','$End_time','$Slot_No')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !  $color')
        window.location.href = 'adddoctor.php';
      </script>";
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>

<?php
include_once 'db.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $Phone_No = $_POST['Phone_No'];
    $Name = $_POST['Name'];
  
    $email = $_POST['email'];
    // $UploadDocument = $_POST['UploadDocument'];
    $reg_id = $_POST['reg_id'];
    $color = $_POST['color'];
    $start_time = ($_POST['start_time']);

    $End_time = $_POST['End_time'];
    $Slot_No = $_POST['Slot_No'];
 
    $name = $_FILES['UploadDocument']['name'];
    list($txt, $ext) = explode(".", $name);
    $image_name = time() . "." . $ext;
    $tmp = $_FILES['UploadDocument']['tmp_name'];

    move_uploaded_file($tmp, 'upload/' . $image_name);

    $name = $_FILES['sign']['name'];
    list($txt, $ext) = explode(".", $name);
    $img_name = time() . "." . $ext;
    $tmp_n = $_FILES['sign']['tmp_name'];

    move_uploaded_file($tmp_n, 'upload/sing/' . $img_name);

    $update = "UPDATE add_doctor set Phone_No='$Phone_No',Name='$Name',email='$email',reg_id='$reg_id',color='$color',UploadDocument='$image_name',sign='$img_name',start_time='$start_time',End_time='$End_time',Slot_No='$Slot_No' WHERE id='$id'";
    if (mysqli_query($con, $update)) {

        echo "<script>alert('updated successfully !')
        window.location.href = 'manage_doctor.php';
      </script>";
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>

<?php
include_once 'db.php';
$delete = "DELETE FROM add_doctor WHERE id='" . $_GET["id"] . "'";
if (mysqli_query($con, $delete)) {
    header("location:manage_doctor.php");
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($con);
?>


