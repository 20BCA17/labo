<?php
include "auth.php";
include "include/header.php";
?>
<?php
include_once 'db.php';
$result = mysqli_query($con, "SELECT * FROM idx_insert WHERE id='" . $_GET['id'] . "'");
$row = mysqli_fetch_array($result);

?>
<style>
    .custom-file-upload {
        background: #f7f7f7;
        padding: 8px;
        border: 1px solid #e3e3e3;
        border-radius: 5px;
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
    }

    .dark {
        background-color: gray;
        color: white;

    }
</style>
<div id="page-wrapper">
    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <h1 class="page-header">
                    Dashboard <small>Summary of your App</small>
                </h1>
              
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Laboratory Management
                    </div>
                    <div class="panel-body">
                        <div class="form-row">
                            <div class="col-lg-12">

                                <form action="" role="form" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">


                            </div>

                            <div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <h1 class="page-header ">
                                            Personal Details
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <input type="text" name="Today_Date" value=" <?php
                                                                                    $currentDateTime = date('d-F-Y');
                                                                                    echo $currentDateTime;
                                                                                    ?>" class="form-control" readonly>
                                </div>
                                <div class="form-group col-md-3">
                                    <select name="Doctor_Name" id="" class="form-control" readonly>
                                        <option value="">Dr Nitin</option>
                                        <option value=""></option>
                                        <option value=""></option>
                                        <option value=""></option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group input-group ">
                                        <input type="text" class="form-control" placeholder="OPD No :" name="Patient_Code" value="<?php echo $row['Patient_Code']; ?>" readonly>
                                        <span class="input-group-btn">
                                            <button class="btn btn-primary" type="submit"><i class="fa fa-pen"></i>
                                            </button>
                                        </span>
                                    </div>
                                </div>
                                <div>
                                    <div class="ph">

                                        <script type="text/javascript">
                                            function preview(event) {
                                                var reader = new FileReader();
                                                reader.onload = function() {
                                                    var output = document.getElementById('output_image');
                                                    output.src = reader.result;
                                                }
                                                reader.readAsDataURL(event.target.files[0]);
                                            }
                                        </script>
                                        <img id="output_image" height=155px width=125px\ src="upload/<?php echo $row['UploadDocument']; ?>">
                                        <input name="UploadDocument" type="file" id="choose" name="file" accept=".jpg,.jpeg,.pdf,doc,docx,application/msword,.png" style="display: none;" onchange="preview(event)" accept="image/*" /><br><br>

                                    </div>



                                    <div class="form-group col-md-2">
                                        <select name="Mr" id="" class="form-control" readonly>
                                            <option value="">Mr</option>
                                            <option value="">Mrs</option>
                                            <option value="">Ms</option>
                                            <option value="">Miss</option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-3">
                                        <input type="text" name="fname" id="" placeholder="First Name" class="form-control" value="<?php echo $row['fname']; ?>" readonly>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <input type="text" name="lname" id="" placeholder="Last Name" class="form-control" value="<?php echo $row['lname']; ?>" readonly>
                                    </div>

                                    <div class="form-group col-md-3">
                                        <input type="text" placeholder="Date Of Birth" onfocus="(this.type='date')" class="form-control" name="dob" value="<?php echo $row['dob']; ?>" readonly>
                                    </div>

                                    <div class="form-group col-md-1 ">
                                        <input type="text" name="dob_year" id="" value="<?php echo $row['dob_year']; ?>" class="form-control" readonly>
                                    </div>
                                    <div class="form-group col-md-1 ">
                                        <input type="text" name="dob_month" id="" value="<?php echo date('M'); ?>" class="form-control" readonly>
                                    </div>
                                    <div class="form-group col-md-2">
                                        <select name="gender" id="" class="form-control" name="Gender" readonly>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Other">Other</option>

                                        </select>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <input type="text" placeholder="mobile" class="form-control" name="Phone" data-minlength="10" maxlength="10" id="mobile" value="<?php echo $row['Phone']; ?>" readonly>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="email" placeholder="Email" class="form-control" name="mail" value="<?php echo $row['mail']; ?>" readonly>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h1 class="page-header ">
                                                Contact Details
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" placeholder="Flat/Door/Block No" class="form-control" name="flat" value="<?php echo $row['flat']; ?>" readonly>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" placeholder="Road/ Street/Lane" class="form-control" name="road" value="<?php echo $row['road']; ?>" readonly>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <input type="text" placeholder="Place" class="form-control" name="place" value="<?php echo $row['place']; ?>" readonly>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <select name="country" id="" class="form-control" readonly>

                                            <option value="">India</option>
                                            <option value="">Us</option>
                                            <option value="">Pk</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <select name="state" id="" class="form-control" readonly>

                                            <option value="">Gujarat</option>
                                            <option value="">Maharastra</option>
                                            <option value="">Uttar Pradesh</option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <input type="text" name="pin" id="" placeholder="Pin/Zip Code" class="form-control" value="<?php echo $row['pin']; ?>" readonly>
                                    </div>


                                    <br><br><br><br><br><br>
                                    <div>
                                    <a href="patient.php" <button class="btn btn-primary">Cancle</button></a>
                                    </div>

                                </div>

                            </div>
                        </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "include/footer.php";
include "include/script.php";
?>