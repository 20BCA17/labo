<?php 
include "auth.php";
include "include/header.php";
?>

<style>

.custom-file-upload{
  background: #f7f7f7;
  padding: 8px;
  border: 1px solid #e3e3e3;
  border-radius: 5px;
  border: 1px solid #ccc;
  display: inline-block;
  padding: 6px 12px;
  cursor: pointer;
}
.dark{
    background-color:gray;
    color:white;

    /* display: inline-block; */
    overflow: hidden;
    white-space: nowrap;
    
}

</style>
      
<div id="page-wrapper">
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                          Lab Work
                    </h1>
				
                </div>
            </div>

            <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Laboratory Management
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">
                                        <form action="lab_detail_insert.php" role="form" method="POST" enctype="multipart/form-data">
                                          
                                          
                                            <div class="form-group  ">
                                                <button type="submit" name="Add" class="btn btn-primary " style="float: right;">Add New
                                                    Lab</button>
                                               
                                                <!-- <button  class="btn btn-primary " id="hide"
                                                    style="float: right;" >Add
                                                    New
                                                    Patient </button> -->
                                            </div><br><br><br><br><br>
                                            <!-- table in data store -->
                                            <?php require "db.php";?>
                                           <?php
                                                $data = mysqli_query($con, "SELECT * FROM lab_detail_insert");
                                            ?>
                                            <div class="table-responsive">
                                            <table class="table table-striped table-hover" id="dataTables-example">
                                                <thead>
                                                    <tr class="dark">
                                                        <th>Select All</th>
                                                        <th>Patient Name</th>
                                                        <th>Order Date</th>
                                                        <th>Doctor Name</th>
                                                        <th>Order Number</th>
                                                        <th>Delivery Date</th>
                                                        <th>Lab Name</th>
                                                        <th>Stage Name</th>
                                                        <th>Toothinfo</th>
                                                        <th>TotalCost</th>
                                                        <th>Lab Status</th>
                                                        <th>action</th>
                                                    
                                                    </tr>
                                                </thead>
                                               <?php foreach ($data as $value) {?> 
                                             
                                                <tr>
                                              <td><input type="checkbox" name="" id=""></td>
                                                    <td><?php echo $value['Patient_Name']; ?></td> 
                                               
                                                    <td><?php echo $value['Start_Date']; ?></td>
                                                    <td><?php echo $value ['Doctor_Name']; ?></td>
                                                    <td><?php echo $value ['Theeth_No']; ?></td>
                                                    <td><?php echo $value['End_Date']; ?></td>
                                                    <td><?php echo $value['Select_Lab']; ?></td>
                                                    <td><?php echo $value['Select_Stage']; ?></td>
                                                    <td><?php echo $value['Toothinfo']; ?></td>
                                                    <td><?php echo $value['Total_Cost']; ?></td>
                                                    <td><?php
                                                         if($value['lab_status']==1){
                                                            echo  '<p>Active</p>';
                                                         }
                                                         else{
                                                            echo ' <p>Deactive</p>';
                                                         }
                                                        ?></td>
                                                  
                                                    <td class="icon">
                                                            <a href="lab_detail_edit.php?id=<?php echo $value['id']; ?>">
                                                                <font color='Blue ' size='4px'><i class="fas fa-edit" aria-hidden="true"></i></font>
                                                            </a>
                                                            &nbsp;
                                                            <a onclick="return confirm('Are you sure?')" href="lab_detail_insert.php?id=<?php echo $value['id']; ?>">
                                                                <font color='red ' size='4px'><i class="fa fa-trash "></i><span class="tooltiptext"></span></font>
                                                            </a>
                                                            &nbsp;

                                                            <a href="ed.php?id=<?php echo $value['id']; ?>">
                                                                <font color='black' size='4px'><i class="fa fa-eye" aria-hidden="true"></i></font>
                                                            </a>
                                                        </td>
                                                    
                                                    
                                                </tr>
                                                
                                                <?php }?>
                                          </table>
                                          </div>
                                            </div>
                                            
                                    </div>

                            </div>
                                            </div>
                        </div>
                    </div>
        </div>
</div>
<?php 
    include "include/footer.php";
    include "include/script.php";
?>