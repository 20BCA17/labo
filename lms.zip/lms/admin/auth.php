<?php
session_start();
// session_destroy();
if(empty($_SESSION['email'])){
  header("Location:login.php");
}
// }else{

// }
?>