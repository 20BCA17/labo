<?php
include_once 'db.php';

if (isset($_POST['ni'])) {
    
    $Component_Category = $_POST['Component_Category'];
    $Component_Name = $_POST['Component_Name'];
    $Component_Discription = $_POST['Component_Discription'];
    $Cost = $_POST['Cost'];
 
  $sql = "INSERT INTO add_item_insert(Component_Category,Component_Name,Component_Discription,Cost)
	 VALUES ('$Component_Category','$Component_Name','$Component_Discription','$Cost')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !')
        window.location.href = 'Add_lab_item.php';
      </script>";
    
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>
<?php
include_once 'db.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $Component_Category = $_POST['Component_Category'];
    $Component_Name = $_POST['Component_Name'];
    $Component_Discription = $_POST['Component_Discription'];
    $Cost = $_POST['Cost'];
 
    $update = "UPDATE add_item_insert set Component_Category='$Component_Category',Component_Name='$Component_Name',Component_Discription='$Component_Discription',Cost='$Cost' WHERE id='$id'";
   if (mysqli_query($con, $update)) {

        echo "<script>alert('updated successfully !')
        window.location.href = 'Add_lab_item.php';
      </script>";
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>


<?php
include_once 'db.php';
$delete = "DELETE FROM add_item_insert WHERE id='" . $_GET["id"] . "'";
if (mysqli_query($con, $delete)) {
    header("location:Add_lab_item.php");
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($con);
?>

<?php

if (isset($_POST['Add'])) {

    header("location:Add_lab_item_form.php");

}

?>
