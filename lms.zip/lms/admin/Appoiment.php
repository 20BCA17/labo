     <?php
      include_once 'db.php';

      if (isset($_POST['submit'])) {

        $sele_patient = $_POST['sele_patient'];
        $title = $_POST['title'];
        $description = $_POST['description'];
        $start_datetime = $_POST['start_datetime'];
        $end_datetime = $_POST['end_datetime'];
        $Chairs = $_POST['Chairs'];
        $Treatmetn = $_POST['Treatmetn'];
        $Notes = $_POST['Notes'];


        $sql = "INSERT INTO appoiment_insert(sele_patient,title,description,start_datetime,end_datetime,Chairs,Treatmetn,Notes)
	 VALUES ('$sele_patient','$title','$description','$start_datetime','$end_datetime','$Chairs','$Treatmetn','$Notes')";
        if (mysqli_query($con, $sql)) {

          echo "<script>alert('New record created successfully !')
        window.location.href = 'Appoiment.php';
      </script>";
        } else {
          echo "Error: " . $sql . "
" . mysqli_error($con);
        }
        mysqli_close($con);
      }

      ?>

     <?php
      include "auth.php";
      include "include/header.php";
      ?>

     <style>
       .custom-file-upload {
         background: #f7f7f7;
         padding: 8px;
         border: 1px solid #e3e3e3;
         border-radius: 5px;
         border: 1px solid #ccc;
         display: inline-block;
         padding: 6px 12px;
         cursor: pointer;
       }

       .dark {
         background-color: gray;
         color: white;

       }

       .icon {
         text-align: center;

       }

       .od {

         border-radius: 50px;
         background-color: #06d69f;
         font-size: 12px;
         color: white;
         text-align: center;
         padding: 10px;

       }

       img {
         background: url(n.png);
         background-repeat: no-repeat;
         background-size: 100px 100px;


       }
     </style>


     <div id="page-wrapper">
       <div id="page-inner">

         <div class="row">
           <div class="col-md-12">
             <h1 class="page-header">
               Dashboard <small>Summary of your App</small>
             </h1>

           </div>
         </div>

         <div class="row">
           <div class="col-lg-12">
             <div class="panel panel-default">
               <div class="panel-heading">
                 Laboratory Management
               </div>
               <div class="panel-body">
                 <div class="form-row">
                   <div class="col-lg-12">

                     <form action="" method="GET">

                       <div class="row">
                         <div class="col-md-4">
                           <div class="form-group">
                             <label>From Date</label>
                             <input type="date" name="from_date" value="<?php if (isset($_GET['from_date'])) {
                                                                          echo $_GET['from_date'];
                                                                        } ?>" class="form-control" required>
                           </div>
                         </div>
                         <div class="col-md-4">
                           <div class="form-group">
                             <label>To Date</label>
                             <input type="date" name="to_date" value="<?php if (isset($_GET['to_date'])) {
                                                                        echo $_GET['to_date'];
                                                                      } ?>" class="form-control">
                           </div>
                         </div>
                         <div class="col-md-4">
                           <div class="form-group">
                             <label><br></label> <br>
                             <button type="submit" class="btn btn-primary" style="color: white;">Filter</button>
                             <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="color: white;float: right;">
                               Add New Appointment
                             </button>
                             <br><br><br><br>
                           </div>
                         </div>
                       </div>
                     </form>
                   </div>
                 </div><br><br><br><br>
                 <?php require "db.php"; ?>
                 <?php
                  // $data = mysqli_query($con, "SELECT * FROM  appoiment_insert WHERE date(start_datetime) = CURDATE();");
                  ?>
                 <div class="card mt-4">
                   <div class="card-body">
                     <table class="table table-striped table-hover  " id="dataTables-example">
                       <thead>
                         <tr class="dark">
                           <th>id</th>
                           <th>Select_patient</th>
                           <th>Patient</th>
                           <th>Doctor_Name</th>
                           <th>Today_Date</th>
                           <th>Date_Time</th>
                           <th>Chairs</th>
                           <th>Treatment </th>
                         </tr>
                       </thead>
                       <tbody>

                         <?php
                          $con = mysqli_connect("localhost", "root", "", "hospital");

                          if (isset($_GET['from_date']) && isset($_GET['to_date'])) {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];

                            $query = "SELECT * FROM appoiment_insert WHERE creat_date BETWEEN '$from_date' AND '$to_date' ";
                            $query_run = mysqli_query($con, $query);

                            if (mysqli_num_rows($query_run) > 0) {

                              foreach ($query_run as $row) {
                          ?>
                               <tr>
                                 <td><?php echo $row['id']; ?></td>
                                 <td><?php echo $row['sele_patient']; ?></td>
                                 <td><?php echo $row['title']; ?></td>
                                 <td><?php echo $row['description']; ?></td>
                                 <td><?php echo $row['start_datetime']; ?></td>
                                 <td><?php echo $row['end_datetime']; ?></td>
                                 <td><?php echo $row['Chairs']; ?></td>
                                 <td><?php echo $row['Treatmetn']; ?></td>
                               </tr>
                           <?php
                              }
                            }
                            ?>
                           <?php } else {
                            $data = "SELECT * FROM  appoiment_insert WHERE date(start_datetime) = CURDATE();";
                            $query_run = mysqli_query($con, $data);
                            if (mysqli_num_rows($query_run) > 0) {
                              foreach ($query_run as $row) {
                            ?>
                               <tr>
                                 <td><?php echo $row['id']; ?></td>
                                 <td><?php echo $row['sele_patient']; ?></td>
                                 <td><?php echo $row['title']; ?></td>
                                 <td><?php echo $row['description']; ?></td>
                                 <td><?php echo $row['start_datetime']; ?></td>
                                 <td><?php echo $row['end_datetime']; ?></td>
                                 <td><?php echo $row['Chairs']; ?></td>
                                 <td><?php echo $row['Treatmetn']; ?></td>
                               </tr>
                         <?php
                              }
                            }
                          } ?>


                       </tbody>
                     </table>


                     <!-- Modal -->
                     <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                       <div class="modal-dialog" role="document">
                         <div class="modal-content">
                           <div class="modal-header" style="background-color: blue; color:white; height: 70px; ">
                             <h4 class="modal-title" id="exampleModalLabel">Appointment</h4>
                             <button type="button" data-dismiss="modal" aria-label="Close" style=" position: relative;top: -25px; right: -540px; background-color:blue; border:1px solid blue;">
                               <i class="fa fa-times" aria-hidden="true" style="color:white;"></i>
                             </button>
                           </div>


                           <html>

                           <head>
                             <link rel="stylesheet" href="app.css">
                             <script>
                               <?php
                                $date = date("Y-m-d-h-i-A");
                                ?>
                             </script>
                           </head>

                           <body>

                             <div class="modal-body">
                               <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                                 <div class="cen">
                                   <div>
                                     <input type="radio" value="Patient" name="sele_patient"><strong>Patient</strong>
                                     <input type="radio" value="New Patient" name="sele_patient"><strong>New Patient</strong>

                                   </div><br>
                                   <div class="">
                                     <label for="Patient">Patient</label>
                                     <?php

                                      require "db.php";
                                      $data = mysqli_query($con, "SELECT * FROM idx_insert");

                                      echo "<select name=title value='' class='form-control for'>Student Name</option>";

                                      foreach ($data as $value) {

                                        echo "<option value='$value[Mr] $value[fname] $value[lname]'>$value[Mr] $value[fname] $value[lname]</option>";
                                      }

                                      echo "</select>";

                                      ?>
                                   </div><br>
                                   <!-- <div class="">
                                     <label for="Doctor Name">Doctor Name</label>
                                     <select name="Doctor_Name" id="" class="form-control for">
                                       <option value="Dr Sahid">Dr Sahid</option>
                                       <option value="Select Patient">Select Patient</option>
                                     </select>
                                   </div> -->
                                   <div class="">
                                     <label for="Doctor Name">Doctor Name</label>
                                     <?php

                                      require "db.php";
                                      $data = mysqli_query($con, "SELECT * FROM add_doctor");

                                      echo "<select name=description value='' class='form-control for'>Student Name</option>";

                                      foreach ($data as $value) {

                                        echo "<option value='$value[Name]'>$value[Name]</option>";
                                      }

                                      echo "</select>";

                                      ?>
                                   </div><br>
                                   <div>
                                     <div class=" col-md-7 ">

                                       <label for="Date & Time "> Date & Time</label>
                                       <input type="text" name="start_datetime" min="<?php echo "$date" ?>" value=" <?php
                                                                                                                    $currentDateTime = date('d  F Y h:i A');
                                                                                                                    echo $currentDateTime;
                                                                                                                    ?>" onfocus="this.type='datetime-local'" class="form-control date">

                                     </div>
                                     <div class=" ">
                                       <label for="Date & Time "> <br></label>
                                       <select name="end_datetime" id="" class="form-control time">
                                         <option value="15 Mins">15 Mins</option>
                                         <option value="25 Mins">25 Mins</option>
                                         <option value="35 Mins">35 Mins</option>
                                       </select>


                                     </div><br>
                                   </div>
                                   <style>
                                     .date {
                                       width: 250px;
                                       margin-left: -14px;
                                       /* transform: translate(8%, 50%); */
                                     }

                                     .cen {
                                       justify-content: center;
                                       margin-left: 55px;
                                     }

                                     .area {
                                       width: 420px;
                                     }
                                   </style>
                                   <div class="">
                                     <label for="Chairs">Chairs</label>
                                     <select name="Chairs" id="" class="form-control for">
                                       <option value="">Select Chair</option>
                                       <option value="1">1</option>
                                       <option value="2">2</option>
                                       <option value="3">3</option>
                                       <option value="4">4</option>
                                       <option value="5">5</option>
                                     </select>
                                   </div><br>
                                   <div class="">
                                     <label for="Treatmetn">Treatmetn</label>
                                     <select name="Treatmetn" id="" class="form-control for">
                                       <option value="">Select Treatmetn</option>
                                       <option value="Allergy Testing">Allergy Testing</option>
                                       <option value="Breast Cancer Screening">Breast Cancer Screening</option>
                                       <option value="Root canal treatment">Root canal treatment</option>
                                     </select>
                                   </div><br>
                                   <div class="">
                                     <label for="Note">Note</label>

                                     <textarea name="Notes" id="" cols="80" rows="3" placeholder="Notes" class="form-control area"> </textarea>

                                   </div><br>

                                   <div class="">
                                     Notification On <input type="color">

                                     <input type="checkbox" name="" id="Doctor_Appoi"> Doctor
                                     <input type="checkbox" name="patient_Appoi">patient

                                   </div>
                                 </div>
                                 <div class="modal-footer ">

                                   <input type="submit" name="submit" value="submit" class="btn btn-primary" id="submit">
                                   <!-- <button type="button" class="btn btn-defult" style="color:blue;" name="ni"><strong>Save</strong>   </button> -->
                                   <button type="button" class="btn btn-secondary" data-dismiss="modal" style="color:black;">Close</button>



                                 </div>
                               </form>
                             </div>


                         </div>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>

               <?php
                include "include/footer.php";
                include "include/script.php";
                ?>