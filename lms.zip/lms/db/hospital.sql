-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2022 at 06:18 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_doctor`
--

CREATE TABLE `add_doctor` (
  `id` int(50) NOT NULL,
  `Phone_No` varchar(15) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `reg_id` varchar(20) NOT NULL,
  `color` varchar(30) NOT NULL,
  `start_time` varchar(10) NOT NULL,
  `End_time` varchar(20) NOT NULL,
  `Slot_No` varchar(20) NOT NULL,
  `UploadDocument` varchar(255) NOT NULL,
  `sign` varchar(255) NOT NULL,
  `stauts` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_doctor`
--

INSERT INTO `add_doctor` (`id`, `Phone_No`, `Name`, `email`, `reg_id`, `color`, `start_time`, `End_time`, `Slot_No`, `UploadDocument`, `sign`, `stauts`) VALUES
(1, '9925828172', 'nitin', 'dubenitin445@gmail.com', '12', '', '', '', '', '1663254104.', '1663254104.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `add_item_insert`
--

CREATE TABLE `add_item_insert` (
  `id` int(50) NOT NULL,
  `Component_Category` varchar(50) NOT NULL,
  `Component_Name` varchar(50) NOT NULL,
  `Component_Discription` varchar(50) NOT NULL,
  `Cost` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_item_insert`
--

INSERT INTO `add_item_insert` (`id`, `Component_Category`, `Component_Name`, `Component_Discription`, `Cost`) VALUES
(1, 'Select Component Category', 'nitin', 'done', '121');

-- --------------------------------------------------------

--
-- Table structure for table `add_lab_insert`
--

CREATE TABLE `add_lab_insert` (
  `id` int(100) NOT NULL,
  `Lab_Name` varchar(50) NOT NULL,
  `Registration` varchar(50) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  `Mobile_No` varchar(15) NOT NULL,
  `Email_Add1` varchar(20) NOT NULL,
  `Email_Add2` varchar(20) NOT NULL,
  `Address_Line1` varchar(255) NOT NULL,
  `Address_Line2` varchar(255) NOT NULL,
  `Country` varchar(20) NOT NULL,
  `State` varchar(20) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Pin` varchar(20) NOT NULL,
  `Notes` varchar(255) NOT NULL,
  `Active` varchar(10) NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `updated_at` timestamp(6) NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_lab_insert`
--

INSERT INTO `add_lab_insert` (`id`, `Lab_Name`, `Registration`, `Contact`, `Mobile_No`, `Email_Add1`, `Email_Add2`, `Address_Line1`, `Address_Line2`, `Country`, `State`, `City`, `Pin`, `Notes`, `Active`, `created_at`, `updated_at`) VALUES
(1, 'fadfsad', 'inn', 'CPM Colony Jk Paper Ltd', '9925828172', 'vrutikapatel47111@gm', 'vrutikapatel47111@gm', 'Ukai Road', 'a', 'India', 'Gujarat', 'Tapi', '394670', ' ok', 'on', '2022-09-15 15:04:57.243287', '2022-09-15 15:04:57.243287');

-- --------------------------------------------------------

--
-- Table structure for table `appoiment_insert`
--

CREATE TABLE `appoiment_insert` (
  `id` int(50) NOT NULL,
  `sele_patient` varchar(20) NOT NULL,
  `title` varchar(20) NOT NULL,
  `description` varchar(20) NOT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` varchar(10) NOT NULL,
  `Chairs` varchar(20) NOT NULL,
  `Treatmetn` varchar(50) NOT NULL,
  `Notes` varchar(255) NOT NULL,
  `creat_date` date DEFAULT current_timestamp(),
  `updat_date` timestamp(6) NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appoiment_insert`
--

INSERT INTO `appoiment_insert` (`id`, `sele_patient`, `title`, `description`, `start_datetime`, `end_datetime`, `Chairs`, `Treatmetn`, `Notes`, `creat_date`, `updat_date`) VALUES
(1, 'Patient', 'Mr Dube Nitin', 'nitin', '2022-09-15 20:44:00', '15 Mins', 'Select Patient', 'Root canal treatment', ' ok', '2022-09-15', '2022-09-15 15:14:57.332912');

-- --------------------------------------------------------

--
-- Table structure for table `idx_insert`
--

CREATE TABLE `idx_insert` (
  `id` int(20) NOT NULL,
  `Today_Date` varchar(20) NOT NULL,
  `Doctor_Name` varchar(50) NOT NULL,
  `Patient_Code` varchar(50) NOT NULL,
  `UploadDocument` text NOT NULL,
  `Mr` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `dob_year` varchar(50) NOT NULL,
  `dob_month` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `flat` varchar(50) NOT NULL,
  `road` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `pin` varchar(50) NOT NULL,
  `Createda_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `Updateda_at` timestamp(6) NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `idx_insert`
--

INSERT INTO `idx_insert` (`id`, `Today_Date`, `Doctor_Name`, `Patient_Code`, `UploadDocument`, `Mr`, `fname`, `lname`, `dob`, `dob_year`, `dob_month`, `gender`, `Phone`, `mail`, `flat`, `road`, `place`, `state`, `country`, `pin`, `Createda_at`, `Updateda_at`) VALUES
(1, ' 15-September-2022', '', '0', '1663254197.png', 'Mr', 'Dube', 'Nitin', '2003-05-27', '19', '', 'Male', '7359817263', 'dubenehal123@gmail.com', '1', 'songadh', 'songadh', '', '', '394670', '2022-09-15 15:03:01.728021', '2022-09-15 15:03:01.728021'),
(2, ' 16-September-2022', '1', '1', '1663340222.jpg', 'Mr', 'Nitin', 'Dube', '1962-11-28', '59', '', 'Male', '9925828172', 'dubenehal123@gmail.com', '12', 'azcc', 'songadh', '', '', '394670', '2022-09-16 14:57:02.514805', '2022-09-16 14:57:02.514805');

-- --------------------------------------------------------

--
-- Table structure for table `lab_detail_insert`
--

CREATE TABLE `lab_detail_insert` (
  `id` int(50) NOT NULL,
  `Start_Date` varchar(20) NOT NULL,
  `Select_Lab` varchar(50) NOT NULL,
  `Doctor_Name` varchar(50) NOT NULL,
  `End_Date` varchar(20) NOT NULL,
  `exampleRadios` varchar(30) NOT NULL,
  `Theeth_No` varchar(10) NOT NULL,
  `Sent` varchar(50) NOT NULL,
  `Select_Stage` varchar(50) NOT NULL,
  `Toothinfo` varchar(20) NOT NULL,
  `Select_Components_items` varchar(50) NOT NULL,
  `Select_Tooth` varchar(20) NOT NULL,
  `Price` varchar(20) NOT NULL,
  `Total_Cost` varchar(20) NOT NULL,
  `Order_Placed` varchar(50) NOT NULL,
  `Instruction` varchar(255) NOT NULL,
  `Created_ad` timestamp(6) NULL DEFAULT current_timestamp(6),
  `Updated_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `Patient_Name` varchar(50) NOT NULL,
  `lab_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(20) NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `updated_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `number` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `created_at`, `updated_at`, `firstName`, `lastName`, `gender`, `email`, `password`, `number`) VALUES
(1, '2022-09-14 14:20:51.795053', '2022-09-14 14:20:51.795053', 'admin', 'admin', 'M', 'admin@gmail.com', '202cb962ac59075b964b07152d234b70', '9928817252'),
(2, '2022-09-16 14:23:51.020238', '2022-09-16 14:23:51.020238', 'aadi', 'aadi', 'M', 'aadi@gmail.com', '202cb962ac59075b964b07152d234b70', '9952828282');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_doctor`
--
ALTER TABLE `add_doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_item_insert`
--
ALTER TABLE `add_item_insert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_lab_insert`
--
ALTER TABLE `add_lab_insert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appoiment_insert`
--
ALTER TABLE `appoiment_insert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `idx_insert`
--
ALTER TABLE `idx_insert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lab_detail_insert`
--
ALTER TABLE `lab_detail_insert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_doctor`
--
ALTER TABLE `add_doctor`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `add_item_insert`
--
ALTER TABLE `add_item_insert`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `add_lab_insert`
--
ALTER TABLE `add_lab_insert`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appoiment_insert`
--
ALTER TABLE `appoiment_insert`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `idx_insert`
--
ALTER TABLE `idx_insert`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lab_detail_insert`
--
ALTER TABLE `lab_detail_insert`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
